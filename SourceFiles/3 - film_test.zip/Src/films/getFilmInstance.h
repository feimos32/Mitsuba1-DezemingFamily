#ifndef __getFilmInstance_h__
#define __getFilmInstance_h__

#include <mitsuba/render/film.h>

MTS_NAMESPACE_BEGIN

class LDRFilm;
class HDRFilm;

ref<Film> getLDRFilm_Instance(const Properties& prop);
ref<Film> getHDRFilm_Instance(const Properties& prop);



MTS_NAMESPACE_END

#endif






