#ifndef __getFiltersInstance_h__
#define __getFiltersInstance_h__

#include <mitsuba/core/rfilter.h>

MTS_NAMESPACE_BEGIN

ref<ReconstructionFilter> getGaussianFilterInstance(const Properties &props);
ref<ReconstructionFilter> getTentFilterInstance(const Properties &props);
ref<ReconstructionFilter> getBoxFilterInstance(const Properties &props);

MTS_NAMESPACE_END


#endif
