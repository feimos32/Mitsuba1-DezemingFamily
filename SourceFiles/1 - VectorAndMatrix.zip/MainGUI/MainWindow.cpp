#include "MainWindow.h"
#include "DebugText.hpp"

#include "Core\Vector.h"
#include "Core\Point.h"
#include "Core\Normal.h"
#include "Core\Matrix.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    
	setMinimumSize(800, 800);

	setCentralWidget(&centralWidget);

	MainWindowLayout.setAlignment(Qt::AlignCenter);

	centralWidget.setLayout(&MainWindowLayout);

	setMenu();


	setWidget();

	setDock();

	
	TextDinodonS("Let's start !");

	Dinodon::Vector4f vec(2.0, 1.0, 3.0, 2.0);
	TextDinVector("vec", vec);
	vec / 0;

	Dinodon::Point4f pot(2.0, 1.0, 3.0, 2.0);
	TextDinPoint("pot", pot);
	pot / 0;

	Dinodon::Normal n(1.0, 1.0, 1.0);
	n = Dinodon::normalize(n);
	TextDinNormal("n", n);

	TextDinodonS("Let's end !");



	TextDinodonS("Matrix Test start !");

	Dinodon::Vector4f vec1(1.0, 2.0, 3.0, 1.0);
	Dinodon::Vector4f vec2(2.0, 1.0, 1.0, 3.0);
	Dinodon::Vector4f vec3(1.0, 3.0, 1.0, 2.0);
	Dinodon::Vector4f vec4(4.0, 1.0, 2.0, 3.0);
	Dinodon::Matrix4x4 m(vec1, vec2, vec3, vec4);
	Dinodon::Matrix4x4 m_ivt;
	bool success = m.invert(m_ivt);
	if (!success) TextDinodonS("EError Unable to invert singular matrix");
	else TextDinMatrix("m_ivt", m_ivt);

	Dinodon::Matrix4x4 I = m * m_ivt;
	TextDinMatrix("I", I);

	TextDinodonS("Matrix Test end !");









}



void MainWindow::setMenu(void) {


}

void MainWindow::setWidget(void) {
	

}

void MainWindow::setDock(void) {
	
}









