#pragma once

#include <QtWidgets/QMainWindow>
#include <QtWidgets/QVBoxLayout>


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = Q_NULLPTR);

private:
	QWidget centralWidget;
	QVBoxLayout MainWindowLayout;

private:
	void setMenu(void);
	void setWidget(void);
	void setDock(void);
};
