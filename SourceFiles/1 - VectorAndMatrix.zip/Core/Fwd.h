#pragma once
#ifndef __FWD_H__
#define __FWD_H__

#include "MainGUI\DebugText.hpp"

namespace Dinodon {



#define SINGLE_PRECISION
#if defined(DOUBLE_PRECISION)
	typedef double Float;
#elif defined(SINGLE_PRECISION)
	typedef float Float;
#else
#error No precision flag was defined!
#endif

	template <int M, int N, typename T> struct Matrix;
	struct Matrix2x2;
	struct Matrix3x3;
	struct Matrix4x4;

	// ****  Vector  *** //
	template <typename T> struct  TVector1;
	template <typename T> struct  TVector2;
	template <typename T> struct  TVector3;
	template <typename T> struct  TVector4;
	typedef TVector1<Float>       Vector1;
	/// \ingroup libpython
	typedef TVector2<Float>       Vector2;
	/// \ingroup libpython
	typedef TVector2<int>         Vector2i;
	typedef TVector2<unsigned int>Vector2u;
	typedef TVector2<float>       Vector2f;
	typedef TVector2<double>      Vector2d;
	/// \ingroup libpython
	typedef TVector3<Float>       Vector;
	/// \ingroup libpython
	typedef TVector3<Float>       Vector3;
	/// \ingroup libpython
	typedef TVector3<int>         Vector3i;
	typedef TVector3<unsigned int>Vector3u;
	typedef TVector3<float>       Vector3f;
	typedef TVector3<double>      Vector3d;
	/// \ingroup libpython
	typedef TVector4<Float>       Vector4;
	typedef TVector4<int>         Vector4i;
	typedef TVector4<unsigned int>Vector4u;
	typedef TVector4<float>       Vector4f;
	typedef TVector4<double>      Vector4d;


	// ****  Point  *** //
	template <typename T> struct  TPoint1;
	template <typename T> struct  TPoint2;
	template <typename T> struct  TPoint3;
	template <typename T> struct  TPoint4;
	typedef TPoint1<Float>        Point1;
	/// \ingroup libpython
	typedef TPoint2<Float>        Point2;
	/// \ingroup libpython
	typedef TPoint2<int>          Point2i;
	typedef TPoint2<unsigned int> Point2u;
	typedef TPoint2<float>        Point2f;
	typedef TPoint2<double>       Point2d;
	/// \ingroup libpython
	typedef TPoint3<Float>        Point;
	/// \ingroup libpython
	typedef TPoint3<Float>        Point3;
	/// \ingroup libpython
	typedef TPoint3<int>          Point3i;
	typedef TPoint3<unsigned int> Point3u;
	typedef TPoint3<float>        Point3f;
	typedef TPoint3<double>       Point3d;
	typedef TPoint4<Float>        Point4;
	typedef TPoint4<int>          Point4i;
	typedef TPoint4<unsigned int> Point4u;
	typedef TPoint4<float>        Point4f;
	typedef TPoint4<double>       Point4d;





}



#endif


