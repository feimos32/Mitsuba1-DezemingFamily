#pragma once
#ifndef __Matrix_h__
#define __Matrix_h__

#include "Constant.h"
#include "Fwd.h"

#include "Vector.h"
#include "Normal.h"
#include "Point.h"

#include <stdlib.h>

namespace Dinodon {

	/**
	* \brief Generic fixed-size dense matrix class using a row-major storage format
	*
	* \ingroup libcore
	*/
	template <int M, int N, typename T> struct Matrix {
	public:
		T m[M][N];

		Matrix() { }

		/// Initialize the matrix with constant entries
		explicit inline Matrix(T value) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] = value;
		}

		/// Initialize the matrix from a given MxN array
		explicit inline Matrix(const T _m[M][N]) {
			memcpy(m, _m, sizeof(T) * M * N);
		}

		/// Initialize the matrix from a given (flat) MxN array in row-major order
		explicit inline Matrix(const T _m[M*N]) {
			memcpy(m, _m, sizeof(T) * M * N);
		}

		/// Copy constructor
		inline Matrix(const Matrix &mtx) {
			memcpy(m, mtx.m, sizeof(T) * M * N);
		}

		/// Initialize with the identity matrix
		void setIdentity() {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] = (i == j) ? 1.0f : 0.0f;
		}

		/// Initialize with zeroes
		void setZero() {
			memset(m, 0, sizeof(T) * M * N);
		}


		/// Indexing operator
		inline T &operator()(int i, int j) { return m[i][j]; }

		/// Indexing operator (const verions)
		inline const T & operator()(int i, int j) const { return m[i][j]; }

		/// Equality operator
		inline bool operator==(const Matrix &mat) const {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					if (m[i][j] != mat.m[i][j])
						return false;
			return true;
		}

		/// Inequality operator
		inline bool operator!=(const Matrix &mat) const {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					if (m[i][j] != mat.m[i][j])
						return true;
			return false;
		}

		/// Assignment operator
		inline Matrix &operator=(const Matrix &mat) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] = mat.m[i][j];
			return *this;
		}

		/// Matrix addition (returns a temporary)
		inline Matrix operator+(const Matrix &mat) const {
			Matrix result;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = m[i][j] + mat.m[i][j];
			return result;
		}

		/// Matrix-scalar addition (returns a temporary)
		inline Matrix operator+(T value) const {
			Matrix result;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = m[i][j] + value;
			return result;
		}

		/// Matrix addition
		inline const Matrix &operator+=(const Matrix &mat) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] += mat.m[i][j];
			return *this;
		}

		/// Matrix-scalar addition
		inline const Matrix &operator+=(T value) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] += value;
			return *this;
		}

		/// Matrix subtraction (returns a temporary)
		inline Matrix operator-(const Matrix &mat) const {
			Matrix result;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = m[i][j] - mat.m[i][j];
			return result;
		}

		/// Matrix-scalar subtraction (returns a temporary)
		inline Matrix operator-(T value) const {
			Matrix result;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = m[i][j] - value;
			return result;
		}

		/// Matrix subtraction
		inline const Matrix &operator-=(const Matrix &mat) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] -= mat.m[i][j];
			return *this;
		}

		/// Matrix-scalar subtraction
		inline const Matrix &operator-(T value) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] -= value;
			return *this;
		}

		/// Matrix-scalar addition
		inline const Matrix &operator-=(T value) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] -= value;
			return *this;
		}

		/// Component-wise negation
		inline Matrix operator-() const {
			Matrix result;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = -m[i][j];
			return result;
		}

		/// Scalar multiplication (creates a temporary)
		inline Matrix operator*(T value) const {
			Matrix result;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = m[i][j] * value;
			return result;
		}

		/// Scalar multiplication
		inline const Matrix& operator*=(T value) {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] *= value;
			return *this;
		}

		/// Scalar division (creates a temporary)
		inline Matrix operator/(T value) const {
			Matrix result;
			if (value == 0) SLog(EWarn, "Matrix: Division by zero!");
			Float recip = 1 / value;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					result.m[i][j] = m[i][j] * recip;
			return result;
		}

		/// Scalar division
		inline const Matrix& operator/=(T value) {
			if (value == 0) SLog(EWarn, "Matrix: Division by zero!");
			Float recip = 1 / value;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					m[i][j] *= recip;
			return *this;
		}

		/// Matrix multiplication (for square matrices)
		inline const Matrix &operator*=(const Matrix &mat) {
			if (N != M) TextDinodonS(" Error(*=) cols in Matrix A not equals to rows in Matrix B");
			Matrix temp = *this * mat;
			*this = temp;
			return *this;
		}

		/// Compute the trace of a square matrix
		inline Float trace() const {
			if (N != M) TextDinodonS(" Error(trace()) cols in Matrix not equals to rows");
			Float sum = 0;
			for (int i = 0; i<M; ++i)
				sum += m[i][i];
			return sum;
		}

		/// Compute the Frobenius norm
		inline Float frob() const {
			Float val = 0;
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					val += m[i][j] * m[i][j];
			return std::sqrt(val);
		}

		/**
		* \brief Compute the LU decomposition of a matrix
		*
		* For an m-by-n matrix A with m >= n, the LU decomposition is an
		* m-by-n unit lower triangular matrix L, an n-by-n upper triangular
		* matrix U,
		*
		* and a permutation vector piv of length m so that A(piv,:) = L*U.
		* If m < n, then L is m-by-m and U is m-by-n.
		*
		* The LU decomposition with pivoting always exists, even if the matrix is
		* singular, so the constructor will never fail.
		* The primary use of the
		*
		* LU decomposition is in the solution of square systems of simultaneous
		* linear equations.
		*
		* \param Target matrix (the L and U parts will be stored
		*        together in a packed format)
		* \param piv Storage for the permutation created by the pivoting
		* \param pivsign Sign of the permutation
		* \return \c true if the matrix was nonsingular.
		*
		* Based on the implementation in JAMA.
		*/
		bool lu(Matrix &LU, int piv[M], int &pivsign) const;

		/**
		* Compute the Cholesky decomposition of a symmetric
		* positive definite matrix
		*
		* \param L Target matrix (a lower triangular matrix such
		*    that A=L*L')
		* \return \c false If the matrix is not symmetric positive
		*    definite.
		* Based on the implementation in JAMA.
		*/
		bool chol(Matrix &L) const;

		/**
		* Solve A*X==B, where \a this is a Cholesky decomposition of \a A created by \ref chol()
		*
		* \param B A matrix with as many rows as \a A and any number of columns
		* \param X A matrix such that L*L'*X == B
		*
		* Based on the implementation in JAMA.
		*/
		template <int K> void cholSolve(const Matrix<M, K, T> &B,
			Matrix<M, K, T> &X) const;

		/**
		* Solve A*X==B, where \a this is a LU decomposition of \a A created by \ref lu()
		*
		* \param B A matrix with as many rows as \a A and any number of  columns
		* \param X A matrix such that L*U*X == B(piv, :)
		* \param piv Pivot vector returned by \ref lu()
		*
		* Based on the implementation in JAMA.
		*/
		template <int K> void luSolve(const Matrix<M, K, T> &B,
			Matrix<M, K, T> &X, int piv[M]) const;

		/**
		* \brief Compute the determinant of a decomposed matrix
		* created by \ref lu()
		*
		* \param pivsign The sign of the pivoting permutation returned
		*        by \ref lu()
		*
		* Based on the implementation in JAMA.
		*/
		T luDet(int pivsign) const;

		/**
		* \brief Compute the determinant of a decomposed matrix
		* created by \ref chol()
		*/

		T cholDet() const;

		/// Check if the matrix is identically zero
		inline bool isZero() const {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					if (m[i][j] != 0)
						return false;
			return true;
		}

		/// Test if this is the identity matrix
		inline bool isIdentity() const {
			for (int i = 0; i<M; ++i) {
				for (int j = 0; j<N; ++j) {
					if (m[i][j] != ((i == j) ? 1 : 0))
						return false;
				}
			}
			return true;
		}

		/**
		* \brief Compute the determinant of a square matrix (internally
		* creates a LU decomposition)
		*/
		inline T det() const {
			Matrix LU;
			int piv[M], pivsign;
			if (!lu(LU, piv, pivsign))
				return 0.0f;
			return LU.luDet(pivsign);
		}

		/// Compute the inverse of a square matrix using the Gauss-Jordan algorithm
		bool invert(Matrix &target) const;

		/**
		* \brief Perform a symmetric eigendecomposition of a square matrix
		* into Q and D.
		*
		* Based on the implementation in JAMA.
		*/
		inline void symEig(Matrix &Q, T d[M]) const {
			if (N != M) TextDinodonS(" Error(symEig): cols in Matrix not equals to rows");
			T e[M];
			Q = *this;
			tred2(Q.m, d, e);
			tql2(Q.m, d, e);
		}

		/// Compute the transpose of this matrix
		inline void transpose(Matrix<N, M, T> &target) const {
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<N; ++j)
					target.m[i][j] = m[j][i];
		}

		/// Return a string representation
		std::string toString() const {
			std::ostringstream oss;
			oss << "Matrix" << M << "x" << N << "[" << std::endl;
			for (int i = 0; i<M; ++i) {
				oss << "  ";
				for (int j = 0; j<N; ++j) {
					oss << m[i][j];
					if (j != N - 1)
						oss << ", ";
				}
				if (i != M - 1)
					oss << ";";
				oss << std::endl;
			}
			oss << "]";
			return oss.str();
		}
	protected:
		/// Symmetric Householder reduction to tridiagonal form.
		static void tred2(T V[M][N], T d[N], T e[N]);

		/// Symmetric tridiagonal QL algorithm.
		static void tql2(T V[M][N], T d[N], T e[N]);
	};

	/**
	* \brief Basic 2x2 matrix data type
	* \ingroup libcore
	*/
	struct Matrix2x2 : public Matrix<2, 2, Float> {
	public:
		inline Matrix2x2() { }

		/// Initialize the matrix with constant entries
		explicit inline Matrix2x2(Float value) : Matrix<2, 2, Float>(value) { }

		/// Initialize the matrix from a given 2x2 array
		explicit inline Matrix2x2(const Float _m[2][2]) : Matrix<2, 2, Float>(_m) { }

		/// Initialize the matrix from a given (float) 2x2 array in row-major order
		explicit inline Matrix2x2(const Float _m[4]) : Matrix<2, 2, Float>(_m) { }

		/// Initialize the matrix from two 2D column vectors
		explicit inline Matrix2x2(const Vector2 &v1, const Vector2 &v2) {
			m[0][0] = v1.x; m[0][1] = v2.x;
			m[1][0] = v1.y; m[1][1] = v2.y;
		}

		/// Copy constructor
		inline Matrix2x2(const Matrix<2, 2, Float> &mtx) : Matrix<2, 2, Float>(mtx) { }

		/// Initialize with the given values
		inline Matrix2x2(Float a00, Float a01, Float a10, Float a11) {
			m[0][0] = a00; m[0][1] = a01;
			m[1][0] = a10; m[1][1] = a11;
		}

		/// Return the determinant (Faster than Matrix::det)
		inline Float det() const {
			return m[0][0] * m[1][1] - m[0][1] * m[1][0];
		}

		/// Compute the inverse (Faster than Matrix::invert)
		__forceinline bool invert2x2(Matrix2x2 &target) const {
			Float det = m[0][0] * m[1][1] - m[0][1] * m[1][0];
			if (std::abs(det) <= RCPOVERFLOW) return false;
			Float invDet = 1 / det;
			target.m[0][0] = m[1][1] * invDet;
			target.m[0][1] = -m[0][1] * invDet;
			target.m[1][1] = m[0][0] * invDet;
			target.m[1][0] = -m[1][0] * invDet;
			return true;
		}
		__forceinline bool invert(Matrix2x2 &target) const {
			return invert2x2(target);
		}

		/// Compute the inverse with det (Faster than Matrix::invert)
		__forceinline bool invert2x2(Matrix2x2 &target, Float& det) const {
			det = m[0][0] * m[1][1] - m[0][1] * m[1][0];
			if (std::abs(det) <= RCPOVERFLOW)
				return false;
			Float invDet = 1 / det;
			target.m[0][0] = m[1][1] * invDet;
			target.m[0][1] = -m[0][1] * invDet;
			target.m[1][1] = m[0][0] * invDet;
			target.m[1][0] = -m[1][0] * invDet;
			return true;
		}

		/// Matrix-vector multiplication
		inline Vector2 operator*(const Vector2 &v) const {
			return Vector2(
				m[0][0] * v.x + m[0][1] * v.y,
				m[1][0] * v.x + m[1][1] * v.y
			);
		}

		/// Scalar multiplication (creates a temporary)
		inline Matrix2x2 operator*(Float value) const {
			Matrix2x2 result;
			for (int i = 0; i<2; ++i)
				for (int j = 0; j<2; ++j)
					result.m[i][j] = m[i][j] * value;
			return result;
		}

		/// Assignment operator
		inline Matrix2x2 &operator=(const Matrix<2, 2, Float> &mat) {
			for (int i = 0; i<2; ++i)
				for (int j = 0; j<2; ++j)
					m[i][j] = mat.m[i][j];
			return *this;
		}

		/// Return a row by index
		inline Vector2 row(int i) const {
			return Vector2(m[i][0], m[i][1]);
		}

		/// Return a column by index
		inline Vector2 col(int i) const {
			return Vector2(m[0][i], m[1][i]);
		}
	};

	/**
	* \brief Basic 3x3 matrix data type
	* \ingroup libcore
	*/
	struct  Matrix3x3 : public Matrix<3, 3, Float> {
	public:
		inline Matrix3x3() { }

		/// Initialize the matrix with constant entries
		explicit inline Matrix3x3(Float value) : Matrix<3, 3, Float>(value) { }

		/// Initialize the matrix from a given 3x3 array
		explicit inline Matrix3x3(const Float _m[3][3]) : Matrix<3, 3, Float>(_m) { }

		/// Initialize the matrix from a given (float) 3x3 array in row-major order
		explicit inline Matrix3x3(const Float _m[9]) : Matrix<3, 3, Float>(_m) { }

		/// Initialize the matrix from three 3D column vectors
		explicit inline Matrix3x3(const Vector &v1, const Vector &v2, const Vector &v3) {
			m[0][0] = v1.x; m[0][1] = v2.x; m[0][2] = v3.x;
			m[1][0] = v1.y; m[1][1] = v2.y; m[1][2] = v3.y;
			m[2][0] = v1.z; m[2][1] = v2.z; m[2][2] = v3.z;
		}

		/// Copy constructor
		inline Matrix3x3(const Matrix<3, 3, Float> &mtx) : Matrix<3, 3, Float>(mtx) { }

		/// Initialize with the given values
		inline Matrix3x3(Float a00, Float a01, Float a02,
			Float a10, Float a11, Float a12,
			Float a20, Float a21, Float a22) {
			m[0][0] = a00; m[0][1] = a01; m[0][2] = a02;
			m[1][0] = a10; m[1][1] = a11; m[1][2] = a12;
			m[2][0] = a20; m[2][1] = a21; m[2][2] = a22;
		}

		/// Return the determinant (Faster than Matrix::det())
		inline Float det() const {
			return ((m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]))
				- (m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]))
				+ (m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])));
		}

		/// Matrix-vector multiplication
		inline Vector operator*(const Vector &v) const {
			return Vector(
				m[0][0] * v.x + m[0][1] * v.y + m[0][2] * v.z,
				m[1][0] * v.x + m[1][1] * v.y + m[1][2] * v.z,
				m[2][0] * v.x + m[2][1] * v.y + m[2][2] * v.z);
		}

		/// multiply the matrix by transpose of v, returns the transpose of the line vector.
		inline Vector preMult(const Vector &v) const {
			return Vector(v.x * m[0][0] + v.y * m[1][0] + v.z * m[2][0],
				v.x * m[0][1] + v.y * m[1][1] + v.z * m[2][1],
				v.x * m[0][2] + v.y * m[1][2] + v.z * m[2][2]);
		}

		/// Scalar multiplication (creates a temporary)
		inline Matrix3x3 operator*(Float value) const {
			Matrix3x3 result;
			for (int i = 0; i<3; ++i)
				for (int j = 0; j<3; ++j)
					result.m[i][j] = m[i][j] * value;
			return result;
		}


		/// Assignment operator
		inline Matrix3x3 &operator=(const Matrix<3, 3, Float> &mat) {
			for (int i = 0; i<3; ++i)
				for (int j = 0; j<3; ++j)
					m[i][j] = mat.m[i][j];
			return *this;
		}

		/// Return a row by index
		inline Vector3 row(int i) const {
			return Vector3(
				m[i][0], m[i][1], m[i][2]
			);
		}

		/// Return a column by index
		inline Vector3 col(int i) const {
			return Vector3(
				m[0][i], m[1][i], m[2][i]
			);
		}
	};


	/**
	* \brief Basic 4x4 matrix data type
	* \ingroup libcore
	* \ingroup libpython
	*/
	struct Matrix4x4 : public Matrix<4, 4, Float> {
		inline Matrix4x4() { }

		/// Initialize the matrix with constant entries
		explicit inline Matrix4x4(Float value) : Matrix<4, 4, Float>(value) { }

		/// Initialize the matrix from a given 4x4 array
		explicit inline Matrix4x4(const Float _m[4][4]) : Matrix<4, 4, Float>(_m) { }

		/// Initialize the matrix from a given (float) 4x4 array in row-major order
		explicit inline Matrix4x4(const Float _m[16]) : Matrix<4, 4, Float>(_m) { }

		/// Initialize the matrix from four 4D column vectors
		explicit inline Matrix4x4(const Vector4 &v1, const Vector4 &v2, const Vector4 &v3, const Vector4 &v4) {
			m[0][0] = v1.x; m[0][1] = v2.x; m[0][2] = v3.x; m[0][3] = v4.x;
			m[1][0] = v1.y; m[1][1] = v2.y; m[1][2] = v3.y; m[1][3] = v4.y;
			m[2][0] = v1.z; m[2][1] = v2.z; m[2][2] = v3.z; m[2][3] = v4.z;
			m[3][0] = v1.w; m[3][1] = v2.w; m[3][2] = v3.w; m[3][3] = v4.w;
		}

		/// Copy constructor
		inline Matrix4x4(const Matrix<4, 4, Float> &mtx) : Matrix<4, 4, Float>(mtx) { }

		/// Initialize with the given values
		inline Matrix4x4(
			Float a00, Float a01, Float a02, Float a03,
			Float a10, Float a11, Float a12, Float a13,
			Float a20, Float a21, Float a22, Float a23,
			Float a30, Float a31, Float a32, Float a33) {
			m[0][0] = a00; m[0][1] = a01; m[0][2] = a02; m[0][3] = a03;
			m[1][0] = a10; m[1][1] = a11; m[1][2] = a12; m[1][3] = a13;
			m[2][0] = a20; m[2][1] = a21; m[2][2] = a22; m[2][3] = a23;
			m[3][0] = a30; m[3][1] = a31; m[3][2] = a32; m[3][3] = a33;
		}

		/// Return the determinant of the upper left 3x3 sub-matrix
		inline Float det3x3() const {
			return ((m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]))
				- (m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]))
				+ (m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0])));
		}

		/// Matrix-vector multiplication
		inline Vector4 operator*(const Vector4 &v) const {
			return Vector4(
				m[0][0] * v.x + m[0][1] * v.y + m[0][2] * v.z + m[0][3] * v.w,
				m[1][0] * v.x + m[1][1] * v.y + m[1][2] * v.z + m[1][3] * v.w,
				m[2][0] * v.x + m[2][1] * v.y + m[2][2] * v.z + m[2][3] * v.w,
				m[3][0] * v.x + m[3][1] * v.y + m[3][2] * v.z + m[3][3] * v.w
			);
		}

		/// Scalar multiplication (creates a temporary)
		inline Matrix4x4 operator*(Float value) const {
			Matrix4x4 result;
			for (int i = 0; i<4; ++i)
				for (int j = 0; j<4; ++j)
					result.m[i][j] = m[i][j] * value;
			return result;
		}

		/// Assignment operator
		inline Matrix4x4 &operator=(const Matrix<4, 4, Float> &mat) {
			for (int i = 0; i<4; ++i)
				for (int j = 0; j<4; ++j)
					m[i][j] = mat.m[i][j];
			return *this;
		}

		/// Return a row by index
		inline Vector4 row(int i) const {
			return Vector4(
				m[i][0], m[i][1], m[i][2], m[i][3]
			);
		}

		/// Return a column by index
		inline Vector4 col(int i) const {
			return Vector4(
				m[0][i], m[1][i], m[2][i], m[3][i]
			);
		}
	};

	/// Matrix multiplication (creates a temporary)
	template <typename T, int M1, int N1, int M2, int N2> inline Matrix<M1, N2, T>
		operator*(const Matrix<M1, N1, T> &mat1, const Matrix<M2, N2, T> &mat2) {
			if(N1 != M2) TextDinodonS("cols in Matrix A not equals to rows in Matrix B");
			Matrix<M1, N2, T> result;
			for (int i = 0; i<M1; ++i) {
				for (int j = 0; j<N2; ++j) {
					T sum = 0;
					for (int k = 0; k<N1; ++k)
						sum += mat1.m[i][k] * mat2.m[k][j];
					result.m[i][j] = sum;
				}
			}
			return result;
		}

		template <typename T, int M, int N> inline Matrix<M, N, T> operator*(T f, const Matrix<M, N, T> &m) {
			return m*f;
		}

		/**
		* \brief Fast 3x3 eigenvalue decomposition
		*
		* \param m
		*    Matrix in question -- will be replaced with the eigenvectors
		* \param lambda
		*    Parameter used to returns the eigenvalues
		* \return
		*    \c true upon success.
		*/
		extern bool eig3(Matrix3x3 &m, Float lambda[3]);

		/**
		* \brief Fast non-iterative 3x3 eigenvalue decomposition
		*
		* \param m
		*    Matrix in question -- will be replaced with the eigenvectors
		* \param lambda
		*    Parameter used to returns the eigenvalues
		*/
		extern void eig3_noniter(Matrix3x3 &m, Float lambda[3]);


		/* Implementations are based on the public domain JAMA library */

		template <int M, int N, typename T> bool Matrix<M, N, T>::chol(Matrix &L) const {
			if (M != N) TextDinodonS("Error(chol()): cols in Matrix not equals to rows");

			for (int j = 0; j < N; j++) {
				T *Lrowj = L.m[j], d = 0;
				for (int k = 0; k < j; k++) {
					T *Lrowk = L.m[k];
					T s = 0;
					for (int i = 0; i < k; i++)
						s += Lrowk[i] * Lrowj[i];
					Lrowj[k] = s = (m[j][k] - s) / L.m[k][k];
					d = d + s*s;
					if (m[k][j] != m[j][k])
						return false;
				}
				d = m[j][j] - d;
				if (d <= 0)
					return false;
				L.m[j][j] = std::sqrt(std::max(d, (T)0));
				for (int k = j + 1; k < N; k++)
					L.m[j][k] = 0;
			}

			return true;
		}

		template <int M, int N, typename T> template <int K> void Matrix<M, N, T>::cholSolve(const Matrix<M, K, T> &B,
			Matrix<M, K, T> &X) const {
			if (M != N) TextDinodonS("Error(cholSolve()): cols in Matrix not equals to rows");

			memcpy(X.m, B.m, sizeof(T)*M*K);

			// Solve L*Y = B;
			for (int k = 0; k < N; k++) {
				for (int j = 0; j < K; j++) {
					for (int i = 0; i < k; i++)
						X.m[k][j] -= X.m[i][j] * m[k][i];
					X.m[k][j] /= m[k][k];
				}
			}

			// Solve L'*X = Y;
			for (int k = N - 1; k >= 0; k--) {
				for (int j = 0; j < K; j++) {
					for (int i = k + 1; i < N; i++)
						X.m[k][j] -= X.m[i][j] * m[i][k];
					X.m[k][j] /= m[k][k];
				}
			}
		}

		template <int M, int N, typename T> bool Matrix<M, N, T>::lu(Matrix &LU,
			int piv[M], int &pivsign) const {
			LU = *this;

			// Computes L and U with the "daxpy"-based elimination algorithm
			for (int i = 0; i < M; i++)
				piv[i] = i;
			pivsign = 1;

			// Main loop.
			for (int k = 0; k < N; k++) {
				// Find pivot.
				int p = k;
				for (int i = k + 1; i < M; i++)
					if (std::abs(LU.m[i][k]) > std::abs(LU.m[p][k]))
						p = i;

				// Exchange if necessary.
				if (p != k) {
					for (int j = 0; j < N; j++)
						std::swap(LU.m[p][j], LU.m[k][j]);
					std::swap(piv[p], piv[k]);
					pivsign = -pivsign;
				}

				// Compute multipliers and eliminate k-th column.
				if (LU.m[k][k] != 0) {
					for (int i = k + 1; i < M; i++) {
						LU.m[i][k] /= LU.m[k][k];
						for (int j = k + 1; j < N; j++)
							LU.m[i][j] -= LU.m[i][k] * LU.m[k][j];
					}
				}
			}
			for (int j = 0; j < N; j++)
				if (LU.m[j][j] == 0)
					return false;
			return true;
		}

		template <int M, int N, typename T> template <int K> void Matrix<M, N, T>::luSolve(const Matrix<M, K, T> &B,
			Matrix<M, K, T> &X, int piv[M]) const {
			if (M != N) TextDinodonS("Error(luSolve()): cols in Matrix not equals to rows");

			// Copy right hand side with pivoting
			for (int i = 0; i<M; ++i)
				for (int j = 0; j<K; ++j)
					X.m[i][j] = B.m[piv[i]][j];

			// Solve L*Y = B(piv,:)
			for (int k = 0; k < N; k++)
				for (int i = k + 1; i < N; i++)
					for (int j = 0; j < K; j++)
						X.m[i][j] -= X.m[k][j] * m[i][k];

			// Solve U*X = Y;
			for (int k = N - 1; k >= 0; k--) {
				for (int j = 0; j < K; j++)
					X.m[k][j] /= m[k][k];

				for (int i = 0; i < k; i++)
					for (int j = 0; j < K; j++)
						X.m[i][j] -= X.m[k][j] * m[i][k];
			}
		}

		template <int M, int N, typename T> T Matrix<M, N, T>::luDet(int pivsign) const {
			if (M != N) TextDinodonS("Error(luDet()): cols in Matrix not equals to rows");
			T d = (T)pivsign;
			for (int j = 0; j < N; j++)
				d *= m[j][j];
			return d;
		}

		template <int M, int N, typename T> T Matrix<M, N, T>::cholDet() const {
			if (M != N) TextDinodonS("Error(cholDet()): cols in Matrix not equals to rows");
			T d = m[0][0];
			for (int j = 1; j < N; j++)
				d *= m[j][j];
			return d*d;
		}

		template <int M, int N, typename T> bool Matrix<M, N, T>::invert(Matrix &target) const {
			if (M != N) TextDinodonS("Error(invert()): cols in Matrix not equals to rows");

			int indxc[N], indxr[N];
			int ipiv[N];
			memset(ipiv, 0, sizeof(int)*N);
			memcpy(target.m, m, M*N * sizeof(T));

			for (int i = 0; i < N; i++) {
				int irow = -1, icol = -1;
				T big = 0;
				for (int j = 0; j < N; j++) {
					if (ipiv[j] != 1) {
						for (int k = 0; k < N; k++) {
							if (ipiv[k] == 0) {
								if (std::abs(target.m[j][k]) >= big) {
									big = std::abs(target.m[j][k]);
									irow = j;
									icol = k;
								}
							}
							else if (ipiv[k] > 1) {
								return false;
							}
						}
					}
				}
				++ipiv[icol];
				if (irow != icol) {
					for (int k = 0; k < N; ++k)
						std::swap(target.m[irow][k], target.m[icol][k]);
				}
				indxr[i] = irow;
				indxc[i] = icol;
				if (target.m[icol][icol] == 0)
					return false;
				T pivinv = 1.f / target.m[icol][icol];
				target.m[icol][icol] = 1.f;
				for (int j = 0; j < N; j++)
					target.m[icol][j] *= pivinv;
				for (int j = 0; j < N; j++) {
					if (j != icol) {
						T save = target.m[j][icol];
						target.m[j][icol] = 0;
						for (int k = 0; k < N; k++)
							target.m[j][k] -= target.m[icol][k] * save;
					}
				}
			}
			for (int j = N - 1; j >= 0; j--) {
				if (indxr[j] != indxc[j]) {
					for (int k = 0; k < N; k++)
						std::swap(target.m[k][indxr[j]], target.m[k][indxc[j]]);
				}
			}
			return true;
		}

		// Symmetric Householder reduction to tridiagonal form.
		template <int M, int N, typename T> void
			Matrix<M, N, T>::tred2(T V[M][N], T d[N], T e[N]) {
			//  This is derived from the Algol procedures tred2 by
			//  Bowdler, Martin, Reinsch, and Wilkinson, Handbook for
			//  Auto. Comp., Vol.ii-Linear Algebra, and the corresponding
			//  Fortran subroutine in EISPACK.

			for (int j = 0; j < N; j++)
				d[j] = V[N - 1][j];

			// Householder reduction to tridiagonal form.
			for (int i = N - 1; i > 0; i--) {
				// Scale to avoid under/overflow.
				T scale = 0.0f, h = 0.0f;

				for (int k = 0; k < i; k++)
					scale = scale + std::abs(d[k]);

				if (scale == 0.0f) {
					e[i] = d[i - 1];
					for (int j = 0; j < i; j++) {
						d[j] = V[i - 1][j];
						V[i][j] = 0.0f;
						V[j][i] = 0.0f;
					}
				}
				else {
					// Generate Householder vector.

					for (int k = 0; k < i; k++) {
						d[k] /= scale;
						h += d[k] * d[k];
					}
					T f = d[i - 1],
						g = std::sqrt(h);

					if (f > 0)
						g = -g;
					e[i] = scale * g;
					h = h - f * g;
					d[i - 1] = f - g;

					for (int j = 0; j < i; j++)
						e[j] = 0.0f;

					// Apply similarity transformation to remaining columns.
					for (int j = 0; j < i; j++) {
						f = d[j];
						V[j][i] = f;
						g = e[j] + V[j][j] * f;
						for (int k = j + 1; k <= i - 1; k++) {
							g += V[k][j] * d[k];
							e[k] += V[k][j] * f;
						}
						e[j] = g;
					}

					f = 0.0f;
					for (int j = 0; j < i; j++) {
						e[j] /= h;
						f += e[j] * d[j];
					}
					T hh = f / (h + h);

					for (int j = 0; j < i; j++)
						e[j] -= hh * d[j];
					for (int j = 0; j < i; j++) {
						f = d[j];
						g = e[j];
						for (int k = j; k <= i - 1; k++)
							V[k][j] -= (f * e[k] + g * d[k]);
						d[j] = V[i - 1][j];
						V[i][j] = 0.0f;
					}
				}
				d[i] = h;
			}

			// Accumulate transformations.
			for (int i = 0; i < N - 1; i++) {
				V[N - 1][i] = V[i][i];
				V[i][i] = 1.0f;
				T h = d[i + 1];

				if (h != 0.0f) {
					for (int k = 0; k <= i; k++)
						d[k] = V[k][i + 1] / h;
					for (int j = 0; j <= i; j++) {
						T g = 0.0f;

						for (int k = 0; k <= i; k++)
							g += V[k][i + 1] * V[k][j];
						for (int k = 0; k <= i; k++)
							V[k][j] -= g * d[k];
					}
				}
				for (int k = 0; k <= i; k++)
					V[k][i + 1] = 0.0f;
			}
			for (int j = 0; j < N; j++) {
				d[j] = V[N - 1][j];
				V[N - 1][j] = 0.0f;
			}
			V[N - 1][N - 1] = 1.0f;
			e[0] = 0.0;
		}

		// Symmetric tridiagonal QL algorithm.
		template <int M, int N, typename T> void
			Matrix<M, N, T>::tql2(T V[M][N], T d[N], T e[N]) {
			//  This is derived from the Algol procedures tql2, by
			//  Bowdler, Martin, Reinsch, and Wilkinson, Handbook for
			//  Auto. Comp., Vol.ii-Linear Algebra, and the corresponding
			//  Fortran subroutine in EISPACK.

			for (int i = 1; i < N; i++)
				e[i - 1] = e[i];

			e[N - 1] = 0.0f;
			T f = 0.0f, tst1 = 0.0f;

#if defined(SINGLE_PRECISION)
			T eps = pow(2.0f, -23.0f);
#else
			T eps = pow(2.0, -52.0);
#endif

			for (int l = 0; l < N; l++) {
				// Find small subdiagonal element
				tst1 = std::max(tst1, std::abs(d[l]) + std::abs(e[l]));
				int m = l;

				while (m < N) {
					if (std::abs(e[m]) <= eps * tst1)
						break;
					m++;
				}

				// If m == l, d[l] is an eigenvalue,
				// otherwise, iterate.
				if (m > l) {
					int iter = 0;

					do {
						iter = iter + 1;    // (Could check iteration count here.)

											// Compute implicit shift
						T g = d[l];
						T p = (d[l + 1] - g) / (2.0f * e[l]);
						T r = math::hypot2((T)1, p);

						if (p < 0)
							r = -r;
						d[l] = e[l] / (p + r);
						d[l + 1] = e[l] * (p + r);
						T dl1 = d[l + 1];

						T h = g - d[l];

						for (int i = l + 2; i < N; i++)
							d[i] -= h;
						f = f + h;

						// Implicit QL transformation.
						p = d[m];
						T c = 1.0f;
						T c2 = c, c3 = c;
						T el1 = e[l + 1];
						T s = 0.0f, s2 = 0.0f;

						for (int i = m - 1; i >= l; i--) {
							c3 = c2;
							c2 = c;
							s2 = s;
							g = c * e[i];
							h = c * p;
							r = math::hypot2(p, e[i]);
							e[i + 1] = s * r;
							s = e[i] / r;
							c = p / r;
							p = c * d[i] - s * g;
							d[i + 1] = h + s * (c * g + s * d[i]);

							// Accumulate transformation.
							for (int k = 0; k < N; k++) {
								h = V[k][i + 1];
								V[k][i + 1] =
									s * V[k][i] + c * h;
								V[k][i] = c * V[k][i] - s * h;
							}
						}
						p = -s * s2 * c3 * el1 * e[l] / dl1;
						e[l] = s * p;
						d[l] = c * p;
						// Check for convergence.
					} while (std::abs(e[l]) > eps * tst1);
				}
				d[l] = d[l] + f;
				e[l] = 0.0f;
			}

			// Sort eigenvalues and corresponding vectors.
			for (int i = 0; i < N - 1; i++) {
				int k = i;

				T p = d[i];

				for (int j = i + 1; j < N; j++) {
					if (d[j] < p) {
						k = j;
						p = d[j];
					}
				}

				if (k != i) {
					d[k] = d[i];
					d[i] = p;
					for (int j = 0; j < N; j++) {
						p = V[j][i];
						V[j][i] = V[j][k];
						V[j][k] = p;
					}
				}
			}
		}


#define  TextDinMatrix(text, mat)  DebugText::getDebugText()->addContents(QString(text) + " -Matrix- " + mat.toString().c_str())


}




#endif





