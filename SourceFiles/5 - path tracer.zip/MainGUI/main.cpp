#include "MainWindow.h"
#include <QtWidgets/QApplication>

#include "DebugText.hpp"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

	TextDinodonS("Start Mitsuba 0.6.0");

    MainWindow w;
    w.show();



    return a.exec();
}




