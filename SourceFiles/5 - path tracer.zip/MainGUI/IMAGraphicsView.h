#pragma once
#ifndef __IMAGraphicsView_h__
#define __IMAGraphicsView_h__

#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGraphicsScene>
#include <QPixmap>
#include <QMouseEvent>

#include <mitsuba/mitsuba.h>
#include <mitsuba/core/version.h>
#include <mitsuba/core/ref.h>
#include <mitsuba/core/matrix.h>
#include <mitsuba/core/bitmap.h>
#include <mitsuba/core/stream.h>
#include <mitsuba/core/mstream.h>
#include <mitsuba/core/fstream.h>
#include <mitsuba/core/appender.h>
#include <mitsuba/core/sched.h>
#include <mitsuba/core/object.h>
#include <mitsuba/core/plugin.h>
#include <mitsuba/core/shvector.h>
#include <mitsuba/core/statistics.h>
#include <mitsuba/core/fresolver.h>
#include <mitsuba/core/util.h>
#include <mitsuba/core/lock.h>

#include <mitsuba/render/film.h>
#include <mitsuba/render/imageblock.h>
#include <mitsuba/render/scenehandler.h>
#include <mitsuba/render/renderjob.h>
#include <mitsuba/render/renderqueue.h>
#include <mitsuba/render/rectwu.h>

#include <boost/filesystem.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/file_status.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/scoped_array.hpp>
#include <map>


// amount of time that a rendering thread will wait for the GUI to accept a
// render view refresh request to show intermediate progress (in ms)
#define REFRESH_TIMEOUT 50
/**
 * Captures progress notifications from mitsuba and helps to transfer
 * them to the Qt event loop.
 */
using mitsuba::Mutex;
using mitsuba::ConditionVariable;
using mitsuba::RectangularWorkUnit;
using mitsuba::RenderJob;
using mitsuba::Point2i;
using mitsuba::ImageBlock;
using mitsuba::Vector2i;
using mitsuba::LockGuard;

namespace mitsuba {
class QRenderListener : public QObject, public mitsuba::RenderListener {
	Q_OBJECT
public:

	QRenderListener() {
		m_mutex = new mitsuba::Mutex();
		m_cond = new mitsuba::ConditionVariable(m_mutex);
		m_refreshRequest = NULL;
	}

	/// Called when work has begun in a rectangular image region
	inline void workBeginEvent(const mitsuba::RenderJob *job, const mitsuba::RectangularWorkUnit *wu, int worker) {
		emit workBegin(job, wu, worker);
	}

	/// Called when work has finished in a rectangular image region
	inline void workEndEvent(const mitsuba::RenderJob *job, const mitsuba::ImageBlock *wr, bool cancelled) {
		emit workEnd(job, wr);
	}

	/// Called when work has been canceled in a rectangular image region
	inline void workCanceledEvent(const RenderJob *job, const Point2i &offset, const Vector2i &size) {
		emit workCanceled(job, offset, size);
	}

	/// Called when the whole target image has been altered in some way
	inline void refreshEvent(const RenderJob *job) {
		LockGuard lock(m_mutex);

		/* Potentially overwrite a previous refresh request */
		m_refreshRequest = job;

		/* Asynchronously signal the GUI */
		emit refresh();

		/* Wait for the GUI to draw the image (or another
			thread to overwrite the refresh request) */
		m_cond->wait(REFRESH_TIMEOUT);

		m_refreshRequest = NULL;
	}

	/// Called when a render job has completed successfully or unsuccessfully
	inline void finishJobEvent(const RenderJob *job, bool cancelled) {
		emit jobFinished(job, cancelled);
	}

	inline const RenderJob *acquireRefreshRequest() { m_mutex->lock(); return m_refreshRequest; }
	inline void releaseRefreshRequest() { m_refreshRequest = NULL; m_cond->signal(); m_mutex->unlock(); }

	MTS_DECLARE_CLASS()
signals:
	void workBegin(const RenderJob *job, const RectangularWorkUnit *wu, int worker);
	void workEnd(const RenderJob *job, const ImageBlock *wr);
	void workCanceled(const RenderJob *job, const Point2i &offset, const Vector2i &size);
	void jobFinished(const RenderJob *job, bool cancelled);
	void refresh();

protected:
	virtual ~QRenderListener() { }

private:
	mitsuba::ref<Mutex> m_mutex;
	mitsuba::ref<mitsuba::ConditionVariable> m_cond;
	const RenderJob *m_refreshRequest;
};

}


struct SceneContext;

class IMAGraphicsView : public QGraphicsView {
	Q_OBJECT

public:
	IMAGraphicsView(QGraphicsView * parent = Q_NULLPTR);
	~IMAGraphicsView();
public:
	void getMap(QString mapname);
	SceneContext *loadScene(const QString &qFileName, const QString &destFile);
	std::map<std::string, std::string, mitsuba::SimpleStringOrdering> m_parameters;
	bool initWorkersProcessArgv();
private:
	int bottom, left, top, right, width, height;
	float _scale = 1.0f;
private:
	QGraphicsScene scene;
	QPixmap map;
	mitsuba::ref<mitsuba::QRenderListener> m_renderListener;
	SceneContext * m_context;
	int m_blockSize;
	mitsuba::ref<mitsuba::RenderQueue> m_renderQueue;
	mitsuba::Thread::EThreadPriority m_workerPriority;
signals:
	
private slots:
	void PaintBuffer(unsigned char * buffer, int width, int height, int channals);
	void setRendering();
	void onJobFinished(const RenderJob *job, bool cancelled);
protected:
	void mouseMoveEvent(QMouseEvent *event);
	void wheelEvent(QWheelEvent *event);
	void mousePressEvent(QMouseEvent *event);
	void drawBackground(QPainter *painter, const QRectF &rect);
	void mouseReleaseEvent(QMouseEvent *event);
};





#endif







