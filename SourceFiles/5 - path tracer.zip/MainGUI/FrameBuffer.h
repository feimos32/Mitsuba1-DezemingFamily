#ifndef __FrameBuffer_h__
#define __FrameBuffer_h__

#include <QImage>
#include <QPixmap>
#include <mitsuba.h>
#include <QObject>

MTS_NAMESPACE_BEGIN

class ArrayFileInfo {
public:
	ArrayFileInfo() { reset(); }
	int width, height;
	int channels;
	int strides[2];
	// Total number of bytes of 'Array'
	size_t size;
	// Number of elements of 'Array' (width * height * channels)
	size_t elementNum;
	// Number of bytes per row of 'Array'
	size_t step;
public:
	void reset(){
		width = 0;
		height = 0;
		channels = 0;
		strides[0] = 0; strides[1] = 0;
		size = 0;
		elementNum = 0;
		step = 0;
	}
};

class FrameBuffer : public Object
{
public:

	/// Initializes the global plugin manager instance
	static void staticInitialization() {
		m_instance = new FrameBuffer();
	}

	/// Free the memory taken by staticInitialization()
	static void staticShutdown() {
		m_instance = NULL;
	}

	inline static FrameBuffer *getInstance() {
		return m_instance;
	}

	void release() {
		arrayInfo.reset();
		if (_array_f != nullptr) delete[] _array_f;
		_array_f = nullptr;
	}

	/** 
	* Get the k-th channel of the data in i-th column in j-th row
	*/
	float getVal(const int i, const int j, const int k) const {
		if (_array_f == nullptr) return .0f;
		if (!hasData()) return .0f;
		if (i >= arrayInfo.width || j >= arrayInfo.height || i < 0 || j < 0 || k < 0 || k >= arrayInfo.channels) {
			// Coordinate access exception
			return -1.0f;
		}

		return _array_f[(i + j * arrayInfo.width) * arrayInfo.channels + k];
	}
	/** 
	* Set the k-th channel of the data in i-th column in j-th row
	*/
	void setVal(const int i, const int j, const int k, const float value) {
		if (_array_f == nullptr) return;
		if (!hasData()) return;
		if (i >= arrayInfo.width || j >= arrayInfo.height || i < 0 || j < 0 || k < 0 || k >= arrayInfo.channels) {
			// Coordinate access exception
			return;
		}
		_array_f[(i + j * arrayInfo.width) * arrayInfo.channels + k] = value;
	}

	int getChannels(void) const {
		if (hasData()) return arrayInfo.channels;
		return 0;
	}

	int getWidth(void) const {
		if (hasData()) return arrayInfo.width;
		return 0;
	}

	int getHeight(void) const {
		if (hasData()) return arrayInfo.height;
		return 0;
	}

	/**
	* 获取图像像素数
	* 长 X 宽 X 通道数 X 每个通道的字节数
	*/
	size_t getPixelNum(void) const {
		if (hasData()) return arrayInfo.height * arrayInfo.width;
		return 0;
	}

	/**
	* 获取图像字节数
	* 长 X 宽 X 通道数 X 每个通道的字节数
	*/
	size_t getDataSize(void) const {
		if (hasData()) return arrayInfo.height * arrayInfo.width * arrayInfo.channels * sizeof(float);
		return 0;
	}

	/**
	* 获取图像总数据量
	* 长 X 宽 X 通道数
	*/
	size_t getDataCount(void) const {
		if (hasData()) return arrayInfo.height * arrayInfo.width * arrayInfo.channels;
		return 0;
	}

	float* getArray(void) {
		if(hasData()) return _array_f;
		return nullptr;
	}

	float* readArray(void) const {
		if (hasData()) return _array_f;
		return nullptr;
	}

	ArrayFileInfo getArrayInfo() const {
		return arrayInfo;
	}

	bool toGraySingleChannel(void) {
		if (!hasData()) return false;
		if (getChannels() < 3) return false;
		float * data = new float[getWidth() * getHeight()];
		if (!data) return false;
		for (int i = 0; i < getWidth(); i++) {
			for (int j = 0; j < getHeight(); j++) {
				int offset_data = (i + j * getWidth());
				data[offset_data] =
					0.299f * getVal(i, j, 0) +
					0.587f * getVal(i, j, 1) +
					0.114f * getVal(i, j, 2);
			}
		}
		bool flag = receiveData(getWidth(), getHeight(), 1, data);
		delete[]data;
		return flag;
	}

	bool receiveData(const int width, const int height, const int channels, const float* source) {
		if (width == 0) return false;
		if (height == 0) return false;
		if (channels == 0) return false;

		arrayInfo.width = width;
		arrayInfo.height = height;
		arrayInfo.channels = channels;
		arrayInfo.elementNum = width * height * channels;
		arrayInfo.size = arrayInfo.elementNum * sizeof(float);

		if (_array_f != nullptr)
			delete[] _array_f;

		_array_f = new float[arrayInfo.elementNum];
		if (!_array_f) {
			arrayInfo.reset();
			return false;
		}

		memcpy(_array_f, source, arrayInfo.size);

		return true;
	}
	
	bool hasData(void) const {
		if (arrayInfo.width == 0) return false;
		if (arrayInfo.height == 0) return false;
		if (arrayInfo.channels == 0) return false;
		if (!_array_f) return false;
		return true;
	}
	MTS_DECLARE_CLASS()
protected:
	FrameBuffer() {
		arrayInfo.reset();
		_array_f = nullptr;
	}
	FrameBuffer(const FrameBuffer& arr) {
		if (receiveData(arr.getWidth(), arr.getHeight(), arr.getChannels(), arr.readArray())) {

		}
		else {
			arrayInfo.reset();
		}
	}
	~FrameBuffer() {
		release();
	}

private:
	float * _array_f;
	ArrayFileInfo arrayInfo;
	static ref<FrameBuffer> m_instance;
};



QImage FrameBufferToQImage(
	const FrameBuffer & arr, 
	bool usingExposure = false, 
	const float exposure = 0.5f);

QPixmap FrameBufferToQPixelMap(
	const FrameBuffer & arr,
	bool usingExposure = false,
	const float exposure = 0.5f);

QImage FrameBufferToQImage(
	const ref<FrameBuffer>  arr,
	bool usingExposure,
	const float exposure);

QPixmap FrameBufferToQPixelMap(
	const ref<FrameBuffer>  arr,
	bool usingExposure,
	const float exposure);

bool Bitmap2FrameBuffer(ref<Film> film, ref<FrameBuffer> framebuffer, float exposure);

MTS_NAMESPACE_END





#endif




