#include "createObject.h"
#include "MainGUI/DebugText.hpp"

#include "Src/bsdfs/getBSDFsInstance.h"

#include "Src/emitters/getEmittersInstance.h"

#include "Src/films/getFilmInstance.h"

#include "Src/integrators/getIntegratorsInstance.h"

#include "Src/medium/getMediumInstance.h"

#include "Src/phase/getPhaseInstance.h"

#include "Src/rfilters/getFiltersInstance.h"

#include "Src/samplers/getSamplersInstance.h"

#include "Src/sensors/getSensorsInstance.h"

#include "Src/shapes/getShapesInstance.h"

#include "Src/subsurface/getSubsurfaceInstance.h"

#include "Src/textures/getTexturesInstance.h"

#include "Src/volume/getVolumeInstance.h"


MTS_NAMESPACE_BEGIN

ref<CreateMtsObject> CreateMtsObject::m_instance = NULL;

CreateMtsObject::CreateMtsObject() {
	m_mutex = new Mutex();
}

CreateMtsObject::~CreateMtsObject() {
	
}


ConfigurableObject *CreateMtsObject::createObject(
	const Class *classType,
	const Properties &props) {
	ConfigurableObject *object = NULL;

	{
		LockGuard lock(m_mutex);
		
		TextDinodonS("Create Object : " + props.getPluginName());
		
		if (props.getPluginName() == "diffuse") {
			object = (ConfigurableObject *)getSmoothDiffuse_Instance(props);
		}
		else if (props.getPluginName() == "area") {
			object = (ConfigurableObject *)getAreaLight_Instance(props);
		}
		else if (props.getPluginName() == "hdrfilm") {
			object = (ConfigurableObject *)getHDRFilm_Instance(props);
		}
		else if (props.getPluginName() == "ldrfilm") {
			object = (ConfigurableObject *)getLDRFilm_Instance(props);
		}
		else if (props.getPluginName() == "path") {
			object = (ConfigurableObject *)getMIPathTracer_Instance(props);
		}
		else if (props.getPluginName() == "gaussian") {
			object = (ConfigurableObject *)getGaussianFilter_Instance(props);
		}
		else if (props.getPluginName() == "ldsampler") {
			object = (ConfigurableObject *)getLowDiscrepancySampler_Instance(props);
		}
		else if (props.getPluginName() == "perspective") {
			object = (ConfigurableObject *)getPerspectiveCameraImpl_Instance(props);
		}
		else if (props.getPluginName() == "obj") {
			object = (ConfigurableObject *)getWavefrontOBJ_Instance(props);
		}
		else {
			TextDinodonS("Mitsuba object " + props.getPluginName() + "not exist!");
		}


	}
	// Dezeming �޸�
	if (!object) return NULL;
	if (!object->getClass()) {
		TextDinodonS("(!object->getClass())");
		return object;
	}

	if (!object->getClass()->derivesFrom(classType)) {
		Log(EError, "Type mismatch when loading plugin \"%s\": Expected "
			"an instance of \"%s\"", props.getPluginName().c_str(), classType->getName().c_str());
		TextDinodonS(
			"Type mismatch when loading plugin " + props.getPluginName() + ": Expected an instance of "
			+ classType->getName() + ". "
		);
	}	
	if (object->getClass()->isAbstract()) {
		Log(EError, "Error when loading plugin \"%s\": Identifies itself as an abstract class",
		props.getPluginName().c_str());
		TextDinodonS(
			"Error when loading plugin " + props.getPluginName() + ": Identifies itself as an abstract class"
		);
	}
		
	return object;
}


ConfigurableObject *CreateMtsObject::createObject(const Properties &props) {
	ConfigurableObject *object = NULL;

	{
		LockGuard lock(m_mutex);
		TextDinodonS("Plugin Name : " + props.getPluginName());

		if (props.getPluginName() == "diffuse") {
			object = (ConfigurableObject *)getSmoothDiffuse_Instance(props);
		}
		else {
			TextDinodonS("Mitsuba object " + props.getPluginName() + "not exist!");
		}

	}
	// Dezeming �޸�
	if (!object) return NULL;
	if (!object->getClass()) {
		TextDinodonS("(!object->getClass())");
		return object;
	}
	if (object->getClass()->isAbstract())
		Log(EError, "Error when loading plugin \"%s\": Identifies itself as an abstract class",
			props.getPluginName().c_str());
	return object;
}


void CreateMtsObject::staticInitialization() {
	m_instance = new CreateMtsObject();
}

void CreateMtsObject::staticShutdown() {
	m_instance = NULL;
}

MTS_IMPLEMENT_CLASS(CreateMtsObject, false, Object)
MTS_NAMESPACE_END













