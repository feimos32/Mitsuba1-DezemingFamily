#include "FrameBuffer.h"
#include "DebugText.hpp"

#include <mitsuba/render/film.h>
#include <mitsuba/core/bitmap.h>

MTS_NAMESPACE_BEGIN

mitsuba::ref<FrameBuffer> FrameBuffer::m_instance;

QImage FrameBufferToQImage(
	const FrameBuffer & arr,
	bool usingExposure,
	const float exposure) {

	if (!arr.hasData()) {
		TextDinodonS("Failed in FrameBufferToQImage!");
		return QImage();
	}

	float* data = arr.readArray();
	unsigned char * _temp = new unsigned char[arr.getWidth() * arr.getHeight() * arr.getChannels()];
	if (!_temp) {
		TextDinodonS("Failed in FrameBufferToQImage!");
		return QImage();
	}
	float invExposure = 1.0 / (1.0 - exposure);
	for (int i = 0; i < arr.getWidth(); i++) {
		for (int j = 0; j < arr.getHeight(); j++) {
			int offset = (i + j * arr.getWidth()) * arr.getChannels();
			for (int k = 0; k < arr.getChannels() && k < 3; k++) {
				if (usingExposure) {
					_temp[offset + k] = 255 * (1.0 - expf(-data[offset + k] * invExposure));
				}
				else {
					_temp[offset + k] = data[offset + k] * 255.0f;
				}
			}
			if (arr.getChannels() == 4) {
				_temp[offset + 3] = 255;
			}
		}
	}

	if (arr.getChannels() == 4) {

		QImage image(_temp,
			arr.getWidth(), arr.getHeight(),
			// step:�����һ��Ԫ�ص��ֽ���
			// step[0]:�����һ��Ԫ�ص��ֽ���
			// step[1] : ������һ��Ԫ�ص��ֽ���
			// step1(0) : ������һ���м���ͨ����
			// step1(1) : һ��Ԫ���м���ͨ����(channel())
			static_cast<int>(arr.getWidth() * 4 * sizeof(unsigned char)),
			QImage::Format_ARGB32);
		image.constBits();
		return image.rgbSwapped();
	}
	else if (arr.getChannels() == 3) {
		QImage image(_temp,
			arr.getWidth(), arr.getHeight(),
			static_cast<int>(arr.getWidth() * 3 * sizeof(unsigned char)),
			QImage::Format_RGB888);

		return image.rgbSwapped();
	}
	else if (arr.getChannels() == 1) {
		QImage image(_temp,
			arr.getWidth(), arr.getHeight(),
			static_cast<int>(arr.getWidth() * 1 * sizeof(unsigned char)),
			QImage::Format_Grayscale8);

		return image;
	}
	delete[] _temp;
	TextDinodonS("Failed in FrameBufferToQImage!");
	return QImage();

}

QPixmap FrameBufferToQPixelMap(
	const FrameBuffer & arr,
	bool usingExposure,
	const float exposure) {
	return QPixmap::fromImage(FrameBufferToQImage(arr, usingExposure, exposure));
}


QImage FrameBufferToQImage(
	const ref<FrameBuffer>  arr,
	bool usingExposure,
	const float exposure) {

	if (!arr->hasData()) {
		TextDinodonS("Failed in FrameBufferToQImage  : (!arr->hasData())!");
		return QImage();
	}

	float* data = arr->readArray();
	unsigned char * _temp = new unsigned char[arr->getWidth() * arr->getHeight() * arr->getChannels()];
	if (!_temp) {
		TextDinodonS("Failed in FrameBufferToQImage : (!_temp)!");
		return QImage();
	}
	float invExposure = 1.0 / (1.0 - exposure);
	for (int i = 0; i < arr->getWidth(); i++) {
		for (int j = 0; j < arr->getHeight(); j++) {
			int offset = (i + j * arr->getWidth()) * arr->getChannels();
			for (int k = 0; k < arr->getChannels() && k < 3; k++) {
				if (usingExposure) {
					_temp[offset + k] = 255 * (1.0 - expf(-data[offset + k] * invExposure));
				}
				else {
					_temp[offset + k] = data[offset + k] * 255.0f;
				}
			}
			if (arr->getChannels() == 4) {
				_temp[offset + 3] = 255;
			}
		}
	}

	if (arr->getChannels() == 4) {

		QImage image(_temp,
			arr->getWidth(), arr->getHeight(),
			// step:�����һ��Ԫ�ص��ֽ���
			// step[0]:�����һ��Ԫ�ص��ֽ���
			// step[1] : ������һ��Ԫ�ص��ֽ���
			// step1(0) : ������һ���м���ͨ����
			// step1(1) : һ��Ԫ���м���ͨ����(channel())
			static_cast<int>(arr->getWidth() * 4 * sizeof(unsigned char)),
			QImage::Format_ARGB32);
		image.constBits();
		return image.rgbSwapped();
	}
	else if (arr->getChannels() == 3) {
		QImage image(_temp,
			arr->getWidth(), arr->getHeight(),
			static_cast<int>(arr->getWidth() * 3 * sizeof(unsigned char)),
			QImage::Format_RGB888);

		return image.rgbSwapped();
	}
	else if (arr->getChannels() == 1) {
		QImage image(_temp,
			arr->getWidth(), arr->getHeight(),
			static_cast<int>(arr->getWidth() * 1 * sizeof(unsigned char)),
			QImage::Format_Grayscale8);

		return image;
	}
	delete[] _temp;
	TextDinodonS("Failed in FrameBufferToQImage!");
	return QImage();

}

QPixmap FrameBufferToQPixelMap(
	const ref<FrameBuffer>  arr,
	bool usingExposure,
	const float exposure) {
	return QPixmap::fromImage(FrameBufferToQImage(arr, usingExposure, exposure));
}


bool Bitmap2FrameBuffer( ref<Film> film, ref<FrameBuffer> framebuffer, float exposure) {

	ref<Bitmap> bitmap;
	bitmap = film->getBitmap()->convert(film->getBitmap()->getPixelFormat(), Bitmap::EFloat);

	std::string s = "image Width: [" + std::to_string(bitmap->getWidth()) 
		+ "]  image Height: [" + std::to_string(bitmap->getHeight())
		+ "]  image PixelFormat: [" + std::to_string(bitmap->getPixelFormat()) + "]";
	TextDinodonS(s);

	Float logAvgLuminance = 0, maxLuminance = 0; // Unused 
	bitmap->tonemapReinhard(logAvgLuminance, maxLuminance, 0.18f, 0.0f);
	float multiplier = std::pow((Float)2, (Float)exposure);
	float m_gamma = -1.0f;
	bitmap = bitmap->convert(Bitmap::ERGBA, Bitmap::EFloat, m_gamma, multiplier);

	framebuffer->receiveData(bitmap->getWidth(), bitmap->getHeight(), 
		bitmap->getChannelCount(), bitmap->getFloatData());

	return true;
}



MTS_IMPLEMENT_CLASS(FrameBuffer, false, Object)
MTS_NAMESPACE_END

