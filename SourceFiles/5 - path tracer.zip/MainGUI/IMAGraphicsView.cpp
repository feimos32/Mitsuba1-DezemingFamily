#include "IMAGraphicsView.h"
#include "DebugText.hpp"

#include <QResource>

#if defined(Assert)
# undef Assert
#endif
#include <xercesc/parsers/SAXParser.hpp>

using namespace mitsuba;

#include "Src/films/getFilmInstance.h"

#include "Src/rfilters/getFiltersInstance.h"

#include "MainGUI/createObject.h"
#include "MainGUI/FrameBuffer.h"

#include "Src/mtsgui/sceneloader.h"
#include "Src/mtsgui/upgrade.h"
#include "Src/mtsgui/Common.h"


#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

void MitsubaInit() {
	using mitsuba::Class;
	using mitsuba::Object;
	using mitsuba::PluginManager;
	using mitsuba::CreateMtsObject;
	using mitsuba::FrameBuffer;
	using mitsuba::Statistics;
	using mitsuba::FileStream;
	using mitsuba::Spectrum;
	using mitsuba::Bitmap;
	using mitsuba::SHVector;
	using mitsuba::Logger;
	using mitsuba::Thread;
	using mitsuba::StreamAppender;
	using mitsuba::Scheduler;
	using mitsuba::Properties;
	using mitsuba::SceneHandler;

	Class::staticInitialization();
	Object::staticInitialization();
	PluginManager::staticInitialization();
	CreateMtsObject::staticInitialization();
	FrameBuffer::staticInitialization();
	Statistics::staticInitialization();
	Thread::staticInitialization();
	Logger::staticInitialization();
	FileStream::staticInitialization();
	Spectrum::staticInitialization();
	Bitmap::staticInitialization();
	Scheduler::staticInitialization();
	SHVector::staticInitialization();
	SceneHandler::staticInitialization();
}
void MitsubaDelete() {
	using mitsuba::ref;
	using mitsuba::Class;
	using mitsuba::PluginManager;
	using mitsuba::CreateMtsObject;
	using mitsuba::FrameBuffer;
	using mitsuba::Statistics;
	using mitsuba::FileStream;
	using mitsuba::Spectrum;
	using mitsuba::Bitmap;
	using mitsuba::SHVector;
	using mitsuba::SceneHandler;
	using mitsuba::Object;
	using mitsuba::Logger;
	using mitsuba::Thread;
	using mitsuba::StreamAppender;
	using mitsuba::Scheduler;

	SceneHandler::staticShutdown();
	SHVector::staticShutdown();
	Scheduler::staticShutdown();
	Bitmap::staticShutdown();
	Spectrum::staticShutdown();
	FileStream::staticShutdown();
	Logger::staticShutdown();
	Thread::staticShutdown();
	Statistics::staticShutdown();
	FrameBuffer::staticShutdown();
	CreateMtsObject::staticShutdown();
	PluginManager::staticShutdown();
	Object::staticShutdown();
	Class::staticShutdown();
}

IMAGraphicsView::IMAGraphicsView(QGraphicsView * parent) {
	setFrameShadow(Sunken);
	setFrameShape(NoFrame);
	//����View����С��ʾ��
	setMinimumHeight(400);
	setMinimumWidth(300);
	//������Ⱦ���򿹾��
	setRenderHint(QPainter::Antialiasing);

	getMap("Icons/background.png");
	
	// ���Ծ�����
	if (0)
	{
		TextDinodonS("Matrix Test start !");

		mitsuba::Vector4f vec1(1.0, 2.0, 3.0, 1.0);
		mitsuba::Vector4f vec2(2.0, 1.0, 1.0, 3.0);
		mitsuba::Vector4f vec3(1.0, 3.0, 1.0, 2.0);
		mitsuba::Vector4f vec4(4.0, 1.0, 2.0, 3.0);
		mitsuba::Matrix4x4 m(vec1, vec2, vec3, vec4);
		mitsuba::Matrix4x4 m_ivt;
		bool success = m.invert(m_ivt);
		if (!success) TextDinodonS("EError Unable to invert singular matrix");
		else TextDinodonS(("m_ivt: " + m_ivt.toString()));

		mitsuba::Matrix4x4 I = m * m_ivt;
		TextDinodonS(("I: " + I.toString()).c_str());

		TextDinodonS("Matrix Test end !");
	}


	using mitsuba::ref;
	using mitsuba::Class;
	using mitsuba::Object;

	using mitsuba::PluginManager;
	using mitsuba::Statistics;
	using mitsuba::FileStream;
	using mitsuba::Spectrum;
	using mitsuba::Bitmap;
	using mitsuba::SHVector;
	using mitsuba::Logger;
	using mitsuba::Thread;
	using mitsuba::StreamAppender;
	using mitsuba::Scheduler;
	using mitsuba::Properties;

	using mitsuba::Film;
	using mitsuba::ImageBlock;
	using mitsuba::SceneHandler;
	using mitsuba::ReconstructionFilter;

	// mitsuba ��̬�����ʼ��
	MitsubaInit();


	// ʹ��Qt��Դ�����ķ�ʽת������Ϊû����Qtע����Դ
	// �����޷���ȷ��������
	if (0)
	{
		/*
		fs::path cat_image_path("./Icons/cat-1.png", boost::filesystem::native);
		bool result = fs::exists(cat_image_path);
		bool result_Resource = QResource::registerResource("./Icons/resources.qrc");
		if (!result || !result_Resource) {
			TextDinodonS("No File in QResource!");
		}
		else {
			try {
				QResource res("./Icons/cat-1.png");
				mitsuba::ref<mitsuba::Stream> mStream = new mitsuba::MemoryStream(res.size());
				TextDinodonS(("res.size(): " + QString::number(res.size())));
				mStream->write(res.data(), res.size());
				mStream->seek(0);
				mitsuba::ref<mitsuba::Bitmap> bitmap = new mitsuba::Bitmap(mitsuba::Bitmap::EPNG, mStream);

			}
			catch (boost::filesystem::filesystem_error &e) {

			}
		}*/
	}

	// ʹ��stb-lib��ȡ��ת��Ϊbitmap
	if (0)
	{
		int width_img, height_img, nrChannels_img;
		unsigned char *data = stbi_load("./Icons/cat-1.png", &width_img, &height_img, &nrChannels_img, 0);
		if (nrChannels_img == 4) {
			// ����bitmap��ȡ��д��
			using mitsuba::Bitmap;
			using mitsuba::Vector2i;
			using mitsuba::FileStream;
			ref<FileStream> fsstream;
			Vector2i size(width_img, height_img);
			mitsuba::ref<mitsuba::Bitmap> bitmap = new mitsuba::Bitmap
				(Bitmap::ERGBA, Bitmap::EUInt8, size, nrChannels_img, data);

			fs::path cat_image_path("./Icons/cat-2.png", boost::filesystem::native);
			bitmap->write(cat_image_path);

			// ����film��ȡ��д��
			
			// ����1��ֱ����bitmap��ֵ��Film
			{
				Properties prop_film;
				prop_film.setInteger("width", width_img);
				prop_film.setInteger("height", height_img);
				ref<Film> m_film = mitsuba::getLDRFilm_Instance_Dez(prop_film);
				m_film->configure();
				m_film->setBitmap(bitmap);

				m_film->savePNG_files("./Icons/cat-3.png", 0.0f);
			}
			
			// ���Զ���ʹ��ImageBlock�����и�ֵ
			Properties prop_filter;
			ref<ReconstructionFilter> filter = mitsuba::getBoxFilter_Instance_Dez(prop_filter);
			filter->configure();
			//TextDinodonS(("filter->getBorderSize(): " + QString::number(filter->getBorderSize())));
			ref<ImageBlock> m_imageblock = new ImageBlock(Bitmap::ESpectrumAlphaWeight, size, filter);
			// �����Ȱ�ͼ������ֵ��Ϊ0����Ϊput()�����ǰ���ֵ�ӵ�ͼ��ԭֵ�ϡ�
			m_imageblock->clear();

			// ����ͼ����и�ֵ
			int width_block = m_imageblock->getBitmap()->getWidth();
			int height_block = m_imageblock->getBitmap()->getHeight();
			// ����ImageBlockʱ��bitmap���͸߶����2��
			// ���width_block��height_block���width_img��height_img��2
			for (int i = 0; i < width_block; i++) {
				for (int j = 0; j < height_block; j++) {
					if (i < width_img && j < height_img) 
					{
						// ԭͼ��ƫ��
						int offset_origin = nrChannels_img * (i + j * width_img);
						// Ŀ��ͼ��ƫ�� 5ͨ��
						int offset_aim = 5 * (i + j * width_block);
						
						mitsuba::Float col[3] = { \
							data[offset_origin + 0] / 255.0f, \
							data[offset_origin + 1] / 255.0f, \
							data[offset_origin + 2] / 255.0f };

						// ֱ����Bitmap�ϸ�ֵ��
						/*{
							m_imageblock->getBitmap()->getFloatData()[offset_aim + 0] = col[0];
							m_imageblock->getBitmap()->getFloatData()[offset_aim + 1] = col[1];
							m_imageblock->getBitmap()->getFloatData()[offset_aim + 2] = col[2];
							// alpha��weight
							m_imageblock->getBitmap()->getFloatData()[offset_aim + 3] = 1.0f;
							m_imageblock->getBitmap()->getFloatData()[offset_aim + 4] = 1.0f;
						}*/
						
						// ʹ��imageblock����ֵ����ʱ��ʹ���˲���
						mitsuba::Point2 pos(i + 0.5, j + 0.5);
						mitsuba::Spectrum s(col);
						m_imageblock->put(pos, s, 1.0);
					}
				}
			}
			// ��ӡ���
			//TextDinodonS(("m_imageblock->getOffset().x: " + QString::number(m_imageblock->getOffset().x)));
			//TextDinodonS(("m_imageblock->getOffset().y: " + QString::number(m_imageblock->getOffset().y)));
			//ref<Bitmap> renderedImage = m_imageblock->getBitmap()->convert(Bitmap::ERGBA, Bitmap::EUInt8);
			//TextDinodonS(("renderedImage->getWidth(): " + QString::number(renderedImage->getWidth())));
			//TextDinodonS(("renderedImage->getHeight(): " + QString::number(renderedImage->getHeight())));
			Properties prop_film;
			// ����Ҫ��֤film��bitmap��Ҫ���뵽bitmap��Сһ��
			// ����ͻᱨ��
			width_img = m_imageblock->getBitmap()->getWidth();
			height_img = m_imageblock->getBitmap()->getHeight();
			prop_film.setInteger("width", width_img);
			prop_film.setInteger("height", height_img);
			ref<Film> m_film = mitsuba::getLDRFilm_Instance_Dez(prop_film);
			m_film->configure();
			m_film->setBitmap(m_imageblock->getBitmap());
			// ����ΪPNGͼ��
			m_film->savePNG_files("./Icons/cat-4.png", 0.0f);
			
		}
		delete[] data;

	}

	// �����ļ���ȡ����
	if (initWorkersProcessArgv())
	{
		QString filename = "D:/Develop/C++/MitsubaProject/Mitsuba scenes/cbox/cbox.xml";
		QFileInfo fInfo(filename);
		fInfo.makeAbsolute();

		m_context = loadScene(filename, "");
		if (m_context != NULL) {
			TextDinodonS("load Scene successfully!");
		}
		else {
			TextDinodonS("(context == NULL)");
		}

		m_blockSize = 32;
		m_renderQueue = new mitsuba::RenderQueue();
		m_renderListener = new mitsuba::QRenderListener();
		m_renderQueue->registerListener(m_renderListener);

		connect(m_renderListener, SIGNAL(jobFinished(const RenderJob *, bool)),
			this, SLOT(onJobFinished(const RenderJob *, bool)), Qt::QueuedConnection);

	}


	setScene(&scene);
	//scene.setBackgroundBrush(QColor(0, 255, 255, 255));
	setCacheMode(CacheBackground);
	scale(_scale, _scale);
}

IMAGraphicsView::~IMAGraphicsView() {
	
	m_renderQueue->unregisterListener(m_renderListener);
	ref<Scheduler> scheduler = Scheduler::getInstance();
	if (scheduler->isRunning())
		scheduler->pause();

	MitsubaDelete();
}

SceneContext *IMAGraphicsView::loadScene(const QString &qFileName, const QString &destFile) {
	ref<FileResolver> resolver = Thread::getThread()->getFileResolver();
	ref<Logger> logger = Thread::getThread()->getLogger();
	fs::path filename = resolver->resolve(toFsPath(qFileName));
	fs::path filePath = fs::absolute(filename).parent_path();
	ref<FileResolver> newResolver = resolver->clone();
	newResolver->prependPath(filePath);
	SceneContext *result = NULL;
	ref<SceneLoader> loadingThread;

retry:
	loadingThread = new SceneLoader(newResolver, filename, toFsPath(destFile), m_parameters);
	
	loadingThread->start();


	while (loadingThread->isRunning()) {
		QCoreApplication::processEvents();
		loadingThread->wait(20);
	}
	loadingThread->join();

	result = loadingThread->getResult();
	if (result == NULL) {
		if (loadingThread->isVersionError()) {
			Version version = loadingThread->getVersion();
			int ret;
			if (version.isValid()) {
				ret = QMessageBox::question(this, tr("Version mismatch -- update scene file?"),
					QString("The requested scene file is from an older version of Mitsuba "
						"(%1). To work with version %2, it will need to be updated. If you "
						"continue, Mitsuba will perform a fully automated upgrade (a "
						"backup copy will be made).\n\nProceed?")
					.arg(version.toString().c_str())
					.arg(MTS_VERSION), QMessageBox::Yes | QMessageBox::Cancel);
			}
			else {
				QMessageBox box(QMessageBox::Question, tr("Version mismatch -- update scene file?"),
					(loadingThread->getError() + "\n\nAlternatively, if this file is from version 0.2.1 "
						"(the last release without explicit version numbers), you can perform a fully "
						"automated upgrade from this version. A backup copy will be made in this case.").c_str());
				QPushButton *version021Button = box.addButton(tr("Assume version 0.2.1?"), QMessageBox::YesRole);
				box.addButton(tr("Cancel"), QMessageBox::RejectRole);
				ret = box.exec();
				if (box.clickedButton() == version021Button) {
					version = Version(0, 2, 1);
					ret = QMessageBox::Yes;
				}
			}
			if (ret == QMessageBox::Yes) {

				UpgradeManager upgradeMgr(newResolver);
				try {
					upgradeMgr.performUpgrade(fromFsPath(filename), version);
					goto retry;
				}
				catch (const std::exception &ex) {
					QMessageBox::critical(this, tr("Unable to update %1").arg(qFileName),
						QString::fromUtf8(ex.what()), QMessageBox::Ok);
				}
			}
			else {
				QMessageBox::critical(this, tr("Unable to load %1").arg(qFileName),
					QString("No upgrade was performed -- giving up."), QMessageBox::Ok);
			}
		}
		else {
			QMessageBox::critical(this, tr("Unable to load %1").arg(qFileName),
				QString::fromUtf8(loadingThread->getError().c_str()),
				QMessageBox::Ok);
		}
	}

	return result;
}

void IMAGraphicsView::setRendering() {
	TextDinodonS("Start Rendering!");
	Scene *scene = m_context->scene;
	if (m_context->renderJob != NULL || scene == NULL)
		return;
	scene->setBlockSize(m_blockSize);

	m_context->renderJob = new RenderJob("rend", scene, m_renderQueue,
		m_context->sceneResID, -1, -1, false, true);
	m_context->cancelMode = ERender;
	m_context->cancelled = false;
	m_context->progress = 0;
	m_context->eta = "";
	m_context->progressName = "";
	m_context->mode = ERender;

	m_context->renderJob->start();
}

void IMAGraphicsView::onJobFinished(const RenderJob *job, bool cancelled) {
	SceneContext *context = m_context;
	if (context == NULL)
		return;
	m_renderQueue->join();
	context->workUnits.clear();
	context->renderJob = NULL;

	TextDinodonS("IMAGraphicsView::onJobFinished");

	map = FrameBufferToQPixelMap(mitsuba::FrameBuffer::getInstance(), true, 0.5f);
	width = map.width();
	height = map.height();
	bottom = -0.5 * height;
	left = -0.5 * width;

	scene.setSceneRect(left, bottom, width, height);
	setScene(&scene);
	scale(0.5, 0.5);
	scale(2.0, 2.0);
}

bool IMAGraphicsView::initWorkersProcessArgv() {
	QSettings settings;
	int localWorkerCount = settings.value("localWorkers", getCoreCount()).toInt();
	ref<Scheduler> scheduler = Scheduler::getInstance();
	QString outputFile("");
	bool beginRendering = false;

	m_workerPriority = (Thread::EThreadPriority)
		settings.value("workerPriority", (int)Thread::ELowPriority).toInt();
	bool useCoreAffinity = localWorkerCount == getCoreCount();
	for (int i = 0; i < localWorkerCount; ++i)
		scheduler->registerWorker(new LocalWorker(useCoreAffinity ? i : -1,
			formatString("wrk%i", i), m_workerPriority));
	scheduler->start();

	return true;
}

void IMAGraphicsView::mouseMoveEvent(QMouseEvent *event) {

}

void IMAGraphicsView::mousePressEvent(QMouseEvent *event) {
	//QGraphicsView ����
	QPoint viewPoint = event->pos();
	//QGraphicsScene ����
	QPointF scenePoint = mapToScene(viewPoint);
	TextDinodonS((  
		QString::number(scenePoint.x()) + " " + QString::number(scenePoint.y())  
		).toStdString());
}

void IMAGraphicsView::mouseReleaseEvent(QMouseEvent *event) {
	//QGraphicsView ����
	QPoint viewPoint = event->pos();
	//QGraphicsScene ����
	QPointF scenePoint = mapToScene(viewPoint);
	TextDinodonS((
		QString::number(scenePoint.x()) + " " + QString::number(scenePoint.y())
		).toStdString());
}

void IMAGraphicsView::drawBackground(QPainter *painter, const QRectF &rect) {
	painter->drawPixmap(int(sceneRect().left()), int(sceneRect().top()), map);
	
}

void IMAGraphicsView::getMap(QString mapname) {
	map.load(mapname);

	width = map.width();
	height = map.height();
	bottom = -0.5 * height;
	left = -0.5 * width;

	scene.setSceneRect(left, bottom, width, height);
}

void IMAGraphicsView::wheelEvent(QWheelEvent *event)
{
	if (event->delta() > 0) {
		_scale = 1.1f;
	}
	else {
		_scale = 0.9f; 
	}
	scale(_scale, _scale); 
}

void IMAGraphicsView::PaintBuffer(unsigned char* buffer, int width, int height, int channals) {
	QImage::Format format;
	if (channals == 4) format = QImage::Format_ARGB32;
	else if (channals == 3) format = QImage::Format_RGB888;
	QImage image(buffer, width, height, static_cast<int>(width * channals * sizeof(unsigned char)), format);
	image.constBits();
	map = QPixmap::fromImage(image.rgbSwapped());

	width = map.width();
	height = map.height();
	bottom = -0.5 * height;
	left = -0.5 * width;
	scene.setSceneRect(left, bottom, width, height);

	setScene(&scene);
	scale(0.5, 0.5);
	scale(2.0, 2.0);
}


MTS_IMPLEMENT_CLASS(QRenderListener, false, RenderListener)
