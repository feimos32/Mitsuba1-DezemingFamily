﻿#pragma once
#ifndef _DEBUGSTEXT_H__
#define _DEBUGSTEXT_H__

#include <QWidget>
#include <qtextedit.h>
#include <qlayout.h>
#include <qmutex.h>
#include <QString>

class DebugText : public QWidget {
	Q_OBJECT

public:
	~DebugText();
	void addContents(const QString& s1);
	static DebugText* getDebugText();

private:
	QTextEdit *ShowDebugArea;
	QHBoxLayout *qlayout;

	DebugText(QWidget * parent = Q_NULLPTR);
	

};

#include <iostream>
#define  TextDinodonS(text)  std::cout << text << std::endl

#define  TextDinodonN(text, num)  std::cout << text << " " << num << std::endl
#define  TextDinodonN2(text, num1, num2)  std::cout << text << " " << num1 << " " << num2 << std::endl
#define  TextDinodonN3(text, num1, num2, num3)  std::cout << text << " " << num1 << " " << num2 << " " << num3 << std::endl
#define  TextDinodonN4(text, num1, num2, num3, num4)  std::cout << text << " " << num1 << " " << num2 << " " << num3 << " " << num4 << std::endl




#endif


