#ifndef __createObject_h__
#define __createObject_h__

#include "core/platform.h"
#include <mitsuba/mitsuba.h>

MTS_NAMESPACE_BEGIN

class MTS_EXPORT_CORE CreateMtsObject : public Object {
public:
	/// Return the global plugin manager
	inline static CreateMtsObject *getInstance() {
		return m_instance;
	}

	/**
	 * \brief return the newly created instance.
	 *
	 * \param classType Expected type of the plugin. An
	 *    exception will be thrown if it turns out not
	 *    to derive from this class.
	 * \param props A \ref Properties instance containing
	 *    all information required to find and construct
	 *    the plugin.
	 */
	ConfigurableObject *createObject(
		const Class *classType,
		const Properties &props
	);

	/**
	 * \brief return the new instance (without verifying its type).
	 *
	 * \param props A \ref Properties instance containing
	 *    all information required to find and construct
	 *    the plugin.
	 */
	ConfigurableObject *createObject(
		const Properties &props
	);

	/// Initializes the global plugin manager instance
	static void staticInitialization();

	/// Free the memory taken by staticInitialization()
	static void staticShutdown();

	MTS_DECLARE_CLASS()
protected:
	CreateMtsObject();

	/// Destruct and unload all plugins
	~CreateMtsObject();
private:
	mutable ref<Mutex> m_mutex;
	static ref<CreateMtsObject> m_instance;
};

MTS_NAMESPACE_END

#endif

