#ifndef __getFilmInstance_h__
#define __getFilmInstance_h__

#include "core/platform.h"

#include <mitsuba/render/film.h>

MTS_NAMESPACE_BEGIN

class LDRFilm;
class HDRFilm;

void* getLDRFilm_Instance(const Properties& prop);
void* getHDRFilm_Instance(const Properties& prop);

ref<Film> getLDRFilm_Instance_Dez(const Properties& prop);
ref<Film> getHDRFilm_Instance_Dez(const Properties& prop);

MTS_NAMESPACE_END

#endif






