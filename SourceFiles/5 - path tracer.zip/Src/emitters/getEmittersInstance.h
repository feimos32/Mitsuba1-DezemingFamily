#ifndef __getEmitttersInstance_h__
#define __getEmitttersInstance_h__

#include "core/platform.h"

MTS_NAMESPACE_BEGIN

void* getAreaLight_Instance(const Properties &props);


MTS_NAMESPACE_END

#endif






