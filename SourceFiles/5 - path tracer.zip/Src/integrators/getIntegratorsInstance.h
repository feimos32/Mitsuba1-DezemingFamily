#ifndef __getIntegratorsInstance_h__
#define __getIntegratorsInstance_h__

#include "core/platform.h"

MTS_NAMESPACE_BEGIN


void* getMIPathTracer_Instance(const Properties& prop);

MTS_NAMESPACE_END

#endif






