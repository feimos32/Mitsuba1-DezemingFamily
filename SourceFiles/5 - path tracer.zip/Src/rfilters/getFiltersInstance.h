#ifndef __getFiltersInstance_h__
#define __getFiltersInstance_h__

#include "core/platform.h"
#include <mitsuba/core/rfilter.h>

MTS_NAMESPACE_BEGIN

void* getGaussianFilter_Instance(const Properties &props);
void* getTentFilter_Instance(const Properties &props);
void* getBoxFilter_Instance(const Properties &props);

ref<ReconstructionFilter> getBoxFilter_Instance_Dez(const Properties &props);
ref<ReconstructionFilter> getGaussianFilter_Instance_Dez(const Properties &props);
MTS_NAMESPACE_END


#endif
