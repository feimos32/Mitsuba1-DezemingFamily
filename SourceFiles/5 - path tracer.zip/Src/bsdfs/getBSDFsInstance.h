#ifndef __getBSDFsInstance_h__
#define __getBSDFsInstance_h__

#include "core/platform.h"

MTS_NAMESPACE_BEGIN


void* getSmoothDiffuse_Instance(const Properties &props);

MTS_NAMESPACE_END

#endif






