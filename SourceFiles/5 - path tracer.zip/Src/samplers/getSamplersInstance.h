#ifndef __getSamplersInstance_h__
#define __getSamplersInstance_h__

#include "core/platform.h"

MTS_NAMESPACE_BEGIN

void* getLowDiscrepancySampler_Instance(const Properties& prop);
void* getIndependentSampler_Instance(const Properties& prop);

ref<Sampler> getIndependentSampler_Instance_Dez(const Properties& prop);

MTS_NAMESPACE_END

#endif






