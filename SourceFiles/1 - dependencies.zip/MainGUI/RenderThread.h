#ifndef __RenderThread_h__
#define __RenderThread_h__

#include <QThread>
#include <QString>

#include "IMAGraphicsView.h"

class RenderThread :public QThread {

	Q_OBJECT
public:
	RenderThread();
	~RenderThread();

public:
	bool renderFlag;
	bool paintFlag;

signals:
	void PrintString(char* s);
	void PaintBuffer(unsigned char* buffer, int width, int height, int channals);
private slots:
	


public:
	void run();


};








#endif






