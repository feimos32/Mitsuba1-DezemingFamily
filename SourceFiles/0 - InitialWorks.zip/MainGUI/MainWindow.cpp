#include "MainWindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    
	setMinimumSize(800, 800);

	setCentralWidget(&centralWidget);

	MainWindowLayout.setAlignment(Qt::AlignCenter);

	centralWidget.setLayout(&MainWindowLayout);

	setMenu();


	setWidget();

	setDock();

}



void MainWindow::setMenu(void) {


}

void MainWindow::setWidget(void) {
	

}

void MainWindow::setDock(void) {
	
}









