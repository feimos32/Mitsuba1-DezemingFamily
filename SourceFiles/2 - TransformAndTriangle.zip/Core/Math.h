#ifndef __Math_h__
#define __Math_h__

#include <algorithm>

namespace Dinodon {

namespace math {


	/// Cast to single precision and round up if not exactly representable
	inline float castflt_up(double val) {
		union {
			float a;
			int b;
		};

		a = (float)val;
		if ((double)a < val)
			b += a < 0 ? -1 : 1;
		return a;
	}

	/// Cast to single precision and round down if not exactly representable (passthrough)
	inline float castflt_down(float val) { return val; }

	/// Square root variant that gracefully handles arguments < 0 that are due to roundoff errors
	inline float safe_sqrt(float value) {
		return std::sqrt(std::max(0.0f, value));
	}

	/// Square root variant that gracefully handles arguments < 0 that are due to roundoff errors
	inline double safe_sqrt(double value) {
		return std::sqrt(std::max(0.0, value));
	}



}

}

#endif




