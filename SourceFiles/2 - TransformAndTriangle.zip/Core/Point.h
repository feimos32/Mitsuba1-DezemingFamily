#pragma once
#ifndef __Point_h__
#define __Point_h__

#include <string>
#include <stdint.h>
#include <algorithm>
#include <sstream>

#include "Core\Fwd.h"

namespace Dinodon {

	/**
	* һάPoint��
	*/
	template <typename T> struct TPoint1 {
		typedef T           Scalar;
		typedef TVector1<T> VectorType;

		T x;

		/// Number of dimensions
		const static int dim = 1;

		/// Ĭ�Ϲ��캯��
		TPoint1() { }

		/// Initialize the point with the specified value
		TPoint1(T x) : x(x) {  }

		/// Initialize the point with the components of another point
		template <typename T1> explicit TPoint1(const TPoint1<T1> &p)
			: x((T)p.x) { }

		/// Initialize the point with the components of a vector data structure
		template <typename T1> explicit TPoint1(const TVector1<T1> &v)
			: x((T)v.x) { }

		/// Add a vector to a point and return the result
		TPoint1 operator+(const TVector1<T> &v) const {
			return TPoint1(x + v.x);
		}

		/// Add two points and return the result (e.g. to compute a weighted position)
		TPoint1 operator+(const TPoint1 &p) const {
			return TPoint1(x + p.x);
		}

		/// Add a vector to this one (e.g. to compute a weighted position)
		TPoint1& operator+=(const TVector1<T> &v) {
			x += v.x;
			return *this;
		}

		/// Add a point to this one (e.g. to compute a weighted position)
		TPoint1& operator+=(const TPoint1 &p) {
			x += p.x;
			return *this;
		}

		/// Subtract a vector from this point
		TPoint1 operator-(const TVector1<T> &v) const {
			return TPoint1(x - v.x);
		}

		/// Subtract two points from each other and return the difference as a vector
		TVector1<T> operator-(const TPoint1 &p) const {
			return TVector1<T>(x - p.x);
		}

		/// Subtract a vector from this point
		TPoint1& operator-=(const TVector1<T> &v) {
			x -= v.x;
			return *this;
		}

		/// Scale the point's coordinates by the given scalar and return the result
		TPoint1 operator*(T f) const {
			return TPoint1(x * f);
		}

		/// Scale the point's coordinates by the given scalar
		TPoint1 &operator*=(T f) {
			x *= f;
			return *this;
		}

		/// Return a version of the point, which has been flipped along the origin
		TPoint1 operator-() const {
			return TPoint1(-x);
		}

		/// Divide the point's coordinates by the given scalar and return the result
		TPoint1 operator/(T f) const {
			if (f == 0) TextDinodonS("EWarn Point1: Division by zero!");

			return TPoint1(x / f);
		}

		/// Divide the point's coordinates by the given scalar
		TPoint1 &operator/=(T f) {
			if (f == 0) TextDinodonS("EWarn Point1: Division by zero!");

			x /= f;
			return *this;
		}

		/// Index into the point's components
		T &operator[](int i) {
			return (&x)[i];
		}

		/// Index into the point's components (const version)
		T operator[](int i) const {
			return (&x)[i];
		}

		/// Return whether or not this point is identically zero
		bool isZero() const {
			return x == 0;
		}

		/// Equality test
		bool operator==(const TPoint1 &v) const {
			return (v.x == x);
		}

		/// Inequality test
		bool operator!=(const TPoint1 &v) const {
			return v.x != x;
		}

		/// Implicit conversion to Scalar
		operator Scalar() const { return x; }

		/// Return a readable string representation of this point
		std::string toString() const {
			std::ostringstream oss;
			oss << "[" << x << "]";
			return oss.str();
		}
	};

	template <typename T> inline TPoint1<T> operator*(T f, const TPoint1<T> &v) {
		return v*f;
	}

	template <typename T> inline T distance(const TPoint1<T> &p1, const TPoint1<T> &p2) {
		return std::abs(p2.x - p2.x);
	}

	template <typename T> inline T distanceSquared(const TPoint1<T> &p1, const TPoint1<T> &p2) {
		return (p1 - p2).lengthSquared();
	}

	template <> inline TPoint1<int> TPoint1<int>::operator/(int s) const {
		if (s == 0) TextDinodonS("EWarn Point1i: Division by zero!");

		return TPoint1(x / s);
	}

	template <> inline TPoint1<int> &TPoint1<int>::operator/=(int s) {
		if (s == 0) TextDinodonS("EWarn Point1i: Division by zero!");
		x /= s;
		return *this;
	}

	/**
	* ��άPoint��
	*/
	template <typename T> struct TPoint2 {
		typedef T           Scalar;
		typedef TVector2<T> VectorType;

		T x, y;

		/// Number of dimensions
		const static int dim = 2;

		/// Ĭ�Ϲ��캯��
		TPoint2() { }

		/// Initialize the point with the specified X, Y and Z components
		TPoint2(T x, T y) : x(x), y(y) {  }

		/// Initialize the point with the components of another point
		template <typename T2> explicit TPoint2(const TPoint2<T2> &p)
			: x((T)p.x), y((T)p.y) { }

		/// Initialize the point with the components of a vector data structure
		template <typename T2> explicit TPoint2(const TVector2<T2> &v)
			: x((T)v.x), y((T)v.y) { }

		/// Initialize all components of the the point with the specified value
		explicit TPoint2(T val) : x(val), y(val) { }

		/// Add a vector to a point and return the result
		TPoint2 operator+(const TVector2<T> &v) const {
			return TPoint2(x + v.x, y + v.y);
		}

		/// Add two points and return the result (e.g. to compute a weighted position)
		TPoint2 operator+(const TPoint2 &p) const {
			return TPoint2(x + p.x, y + p.y);
		}

		/// Add a vector to this one (e.g. to compute a weighted position)
		TPoint2& operator+=(const TVector2<T> &v) {
			x += v.x; y += v.y;
			return *this;
		}

		/// Add a point to this one (e.g. to compute a weighted position)
		TPoint2& operator+=(const TPoint2 &p) {
			x += p.x; y += p.y;
			return *this;
		}

		/// Subtract a vector from this point
		TPoint2 operator-(const TVector2<T> &v) const {
			return TPoint2(x - v.x, y - v.y);
		}

		/// Subtract two points from each other and return the difference as a vector
		TVector2<T> operator-(const TPoint2 &p) const {
			return TVector2<T>(x - p.x, y - p.y);
		}

		/// Subtract a vector from this point
		TPoint2& operator-=(const TVector2<T> &v) {
			x -= v.x; y -= v.y;
			return *this;
		}

		/// Scale the point's coordinates by the given scalar and return the result
		TPoint2 operator*(T f) const {
			return TPoint2(x * f, y * f);
		}

		/// Scale the point's coordinates by the given scalar
		TPoint2 &operator*=(T f) {
			x *= f; y *= f;
			return *this;
		}

		/// Return a version of the point, which has been flipped along the origin
		TPoint2 operator-() const {
			return TPoint2(-x, -y);
		}

		/// Divide the point's coordinates by the given scalar and return the result
		TPoint2 operator/(T f) const {
			if (f == 0) TextDinodonS("EWarn Point2: Division by zero!");

			T recip = (T)1 / f;
			return TPoint2(x * recip, y * recip);
		}

		/// Divide the point's coordinates by the given scalar
		TPoint2 &operator/=(T f) {
			if (f == 0) TextDinodonS("EWarn Point2: Division by zero!");
			T recip = (T)1 / f;
			x *= recip; y *= recip;
			return *this;
		}

		/// Index into the point's components
		T &operator[](int i) {
			return (&x)[i];
		}

		/// Index into the point's components (const version)
		T operator[](int i) const {
			return (&x)[i];
		}

		/// Return whether or not this point is identically zero
		bool isZero() const {
			return x == 0 && y == 0;
		}

		/// Equality test
		bool operator==(const TPoint2 &v) const {
			return (v.x == x && v.y == y);
		}

		/// Inequality test
		bool operator!=(const TPoint2 &v) const {
			return v.x != x || v.y != y;
		}

		/// Return a readable string representation of this point
		std::string toString() const {
			std::ostringstream oss;
			oss << "[" << x << ", " << y << "]";
			return oss.str();
		}
	};

	template <typename T> inline TPoint2<T> operator*(T f, const TPoint2<T> &v) {
		return v*f;
	}

	template <typename T> inline T distance(const TPoint2<T> &p1, const TPoint2<T> &p2) {
		return (p1 - p2).length();
	}

	template <typename T> inline T distanceSquared(const TPoint2<T> &p1, const TPoint2<T> &p2) {
		return (p1 - p2).lengthSquared();
	}

	template <> inline TPoint2<int> TPoint2<int>::operator/(int s) const {
		if (s == 0)	TextDinodonS("EWarn Point2i: Division by zero!");
		return TPoint2(x / s, y / s);
	}

	template <> inline TPoint2<int> &TPoint2<int>::operator/=(int s) {
		if (s == 0) TextDinodonS("EWarn Point2i: Division by zero!");
		x /= s;
		y /= s;
		return *this;
	}

	/**
	* ��άPoint��
	*/
	template <typename T> struct TPoint3 {
		typedef T           Scalar;
		typedef TVector3<T> VectorType;

		T x, y, z;

		/// Number of dimensions
		const static int dim = 3;

		/// Ĭ�Ϲ��캯��
		TPoint3() { }

		/// Initialize the point with the specified X, Y and Z components
		TPoint3(T x, T y, T z) : x(x), y(y), z(z) {  }

		/// Initialize the point with the components of another point
		template <typename T2> explicit TPoint3(const TPoint3<T2> &p)
			: x((T)p.x), y((T)p.y), z((T)p.z) { }

		/// Initialize the point with the components of a vector data structure
		template <typename T2> explicit TPoint3(const TVector3<T2> &v)
			: x((T)v.x), y((T)v.y), z((T)v.z) { }

		/// Initialize all components of the the point with the specified value
		explicit TPoint3(T val) : x(val), y(val), z(val) { }

		/// Add a vector to a point and return the result
		TPoint3 operator+(const TVector3<T> &v) const {
			return TPoint3(x + v.x, y + v.y, z + v.z);
		}

		/// Add two points and return the result (e.g. to compute a weighted position)
		TPoint3 operator+(const TPoint3 &p) const {
			return TPoint3(x + p.x, y + p.y, z + p.z);
		}

		/// Add a vector to this one (e.g. to compute a weighted position)
		TPoint3& operator+=(const TVector3<T> &v) {
			x += v.x; y += v.y; z += v.z;
			return *this;
		}

		/// Add a point to this one (e.g. to compute a weighted position)
		TPoint3& operator+=(const TPoint3 &p) {
			x += p.x; y += p.y; z += p.z;
			return *this;
		}

		/// Subtract a vector from this point
		TPoint3 operator-(const TVector3<T> &v) const {
			return TPoint3(x - v.x, y - v.y, z - v.z);
		}

		/// Subtract two points from each other and return the difference as a vector
		TVector3<T> operator-(const TPoint3 &p) const {
			return TVector3<T>(x - p.x, y - p.y, z - p.z);
		}

		/// Subtract a vector from this point
		TPoint3& operator-=(const TVector3<T> &v) {
			x -= v.x; y -= v.y; z -= v.z;
			return *this;
		}

		/// Scale the point's coordinates by the given scalar and return the result
		TPoint3 operator*(T f) const {
			return TPoint3(x * f, y * f, z * f);
		}

		/// Scale the point's coordinates by the given scalar
		TPoint3 &operator*=(T f) {
			x *= f; y *= f; z *= f;
			return *this;
		}

		/// Return a version of the point, which has been flipped along the origin
		TPoint3 operator-() const {
			return TPoint3(-x, -y, -z);
		}

		/// Divide the point's coordinates by the given scalar and return the result
		TPoint3 operator/(T f) const {
			if (f == 0) TextDinodonS("EWarn Point3: Division by zero!");
			T recip = (T)1 / f;
			return TPoint3(x * recip, y * recip, z * recip);
		}

		/// Divide the point's coordinates by the given scalar
		TPoint3 &operator/=(T f) {
			if (f == 0) TextDinodonS("EWarn Point3: Division by zero!");
			T recip = (T)1 / f;
			x *= recip; y *= recip; z *= recip;
			return *this;
		}

		/// Index into the point's components
		T &operator[](int i) {
			return (&x)[i];
		}

		/// Index into the point's components (const version)
		T operator[](int i) const {
			return (&x)[i];
		}

		/// Return whether or not this point is identically zero
		bool isZero() const {
			return x == 0 && y == 0 && z == 0;
		}

		/// Equality test
		bool operator==(const TPoint3 &v) const {
			return (v.x == x && v.y == y && v.z == z);
		}

		/// Inequality test
		bool operator!=(const TPoint3 &v) const {
			return v.x != x || v.y != y || v.z != z;
		}

		/// Return a readable string representation of this point
		std::string toString() const {
			std::ostringstream oss;
			oss << "[" << x << ", " << y << ", " << z << "]";
			return oss.str();
		}
	};

	template <typename T> inline TPoint3<T> operator*(T f, const TPoint3<T> &v) {
		return v*f;
	}

	template <typename T> inline T distance(const TPoint3<T> &p1, const TPoint3<T> &p2) {
		return (p1 - p2).length();
	}

	template <typename T> inline T distanceSquared(const TPoint3<T> &p1, const TPoint3<T> &p2) {
		return (p1 - p2).lengthSquared();
	}

	template <> inline TPoint3<int> TPoint3<int>::operator/(int s) const {
		if (s == 0) TextDinodonS("EWarn Point3i: Division by zero!");
		return TPoint3(x / s, y / s, z / s);
	}

	template <> inline TPoint3<int> &TPoint3<int>::operator/=(int s) {
		if (s == 0)	TextDinodonS("EWarn Point3i: Division by zero!");
		x /= s;
		y /= s;
		z /= s;
		return *this;
	}

	/**
	* ��άPoint��
	*/
	template <typename T> struct TPoint4 {
		typedef T           Scalar;
		typedef TVector4<T> VectorType;

		T x, y, z, w;

		/// Number of dimensions
		const static int dim = 4;

		/// Ĭ�Ϲ��캯��
		TPoint4() { }

		/// Initialize the point with the specified X, Y and Z components
		TPoint4(T x, T y, T z, T w) : x(x), y(y), z(z), w(w) {  }

		/// Initialize the point with the components of another point
		template <typename T2> explicit TPoint4(const TPoint4<T2> &p)
			: x((T)p.x), y((T)p.y), z((T)p.z), w((T)p.w) { }

		/// Initialize the point with the components of a vector data structure
		template <typename T2> explicit TPoint4(const TVector4<T2> &v)
			: x((T)v.x), y((T)v.y), z((T)v.z), w((T)v.w) { }

		/// Initialize all components of the the point with the specified value
		explicit TPoint4(T val) : x(val), y(val), z(val), w(val) { }

		/// Add a vector to a point and return the result
		TPoint4 operator+(const TVector4<T> &v) const {
			return TPoint4(x + v.x, y + v.y, z + v.z, w + v.w);
		}

		/// Add two points and return the result (e.g. to compute a weighted position)
		TPoint4 operator+(const TPoint4 &p) const {
			return TPoint4(x + p.x, y + p.y, z + p.z, w + p.w);
		}

		/// Add a vector to this one (e.g. to compute a weighted position)
		TPoint4& operator+=(const TVector4<T> &v) {
			x += v.x; y += v.y; z += v.z; w += v.w;
			return *this;
		}

		/// Add a point to this one (e.g. to compute a weighted position)
		TPoint4& operator+=(const TPoint4 &p) {
			x += p.x; y += p.y; z += p.z; w += p.w;
			return *this;
		}

		/// Subtract a vector from this point
		TPoint4 operator-(const TVector4<T> &v) const {
			return TPoint4(x - v.x, y - v.y, z - v.z, w - v.w);
		}

		/// Subtract two points from each other and return the difference as a vector
		TVector4<T> operator-(const TPoint4 &p) const {
			return TVector4<T>(x - p.x, y - p.y, z - p.z, w - p.w);
		}

		/// Subtract a vector from this point
		TPoint4& operator-=(const TVector4<T> &v) {
			x -= v.x; y -= v.y; z -= v.z; w -= v.w;
			return *this;
		}

		/// Scale the point's coordinates by the given scalar and return the result
		TPoint4 operator*(T f) const {
			return TPoint4(x * f, y * f, z * f, w * f);
		}

		/// Scale the point's coordinates by the given scalar
		TPoint4 &operator*=(T f) {
			x *= f; y *= f; z *= f; w *= f;
			return *this;
		}

		/// Return a version of the point, which has been flipped along the origin
		TPoint4 operator-() const {
			return TPoint4(-x, -y, -z, -w);
		}

		/// Divide the point's coordinates by the given scalar and return the result
		TPoint4 operator/(T f) const {
			if (f == 0) TextDinodonS("EWarn Point4: Division by zero!");
			T recip = (T)1 / f;
			return TPoint4(x * recip, y * recip, z * recip, w * recip);
		}

		/// Divide the point's coordinates by the given scalar
		TPoint4 &operator/=(T f) {
			if (f == 0) TextDinodonS("EWarn Point4: Division by zero!");
			T recip = (T)1 / f;
			x *= recip; y *= recip; z *= recip; w *= recip;
			return *this;
		}

		/// Index into the point's components
		T &operator[](int i) {
			return (&x)[i];
		}

		/// Index into the point's components (const version)
		T operator[](int i) const {
			return (&x)[i];
		}

		/// Return whether or not this point is identically zero
		bool isZero() const {
			return x == 0 && y == 0 && z == 0 && w == 0;
		}

		/// Equality test
		bool operator==(const TPoint4 &v) const {
			return (v.x == x && v.y == y && v.z == z && v.w == w);
		}

		/// Inequality test
		bool operator!=(const TPoint4 &v) const {
			return v.x != x || v.y != y || v.z != z || v.w != w;
		}

		/// Return a readable string representation of this point
		std::string toString() const {
			std::ostringstream oss;
			oss << "[" << x << ", " << y << ", " << z << ", " << w << "]";
			return oss.str();
		}
	};

	template <typename T> inline TPoint4<T> operator*(T f, const TPoint4<T> &v) {
		return v*f;
	}

	template <typename T> inline T distance(const TPoint4<T> &p1, const TPoint4<T> &p2) {
		return (p1 - p2).length();
	}

	template <typename T> inline T distanceSquared(const TPoint4<T> &p1, const TPoint4<T> &p2) {
		return (p1 - p2).lengthSquared();
	}

	template <> inline TPoint4<int> TPoint4<int>::operator/(int s) const {
		if (s == 0) TextDinodonS("EWarn Point4i: Division by zero!");

		return TPoint4(x / s, y / s, z / s, w / s);
	}

	template <> inline TPoint4<int> &TPoint4<int>::operator/=(int s) {
		if (s == 0) TextDinodonS("EWarn Point4i: Division by zero!");
		x /= s;
		y /= s;
		z /= s;
		w /= s;
		return *this;
	}

}

#define  TextDinPoint(text, pot)  DebugText::getDebugText()->addContents(QString(text) + " -Point- " + pot.toString().c_str())

#endif



