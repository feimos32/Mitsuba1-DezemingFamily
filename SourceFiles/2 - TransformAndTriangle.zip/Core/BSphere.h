#ifndef __BSphere_h__
#define __BSphere_h__

#include <algorithm>

#include "Point.h"
#include "Vector.h"
#include "Ray.h"
#include "Util.h"

namespace Dinodon {

	/** \brief Bounding sphere data structure in three dimensions
	*
	* \ingroup libcore
	* \ingroup libpython
	*/
	struct BSphere {
		Point center;
		Float radius;

		/// Construct a bounding sphere at the origin having radius zero
		inline BSphere() : center(0.0f), radius(0.0f) { }

		/// Create a bounding sphere from a given center point and radius
		inline BSphere(const Point &center, Float radius)
			: center(center), radius(radius) {
		}

		/// Copy constructor
		inline BSphere(const BSphere &boundingSphere)
			: center(boundingSphere.center), radius(boundingSphere.radius) {
		}

		/// Return whether this bounding sphere has a radius of zero or less.
		inline bool isEmpty() const {
			return radius <= 0.0f;
		}

		/// Expand the bounding sphere radius to contain another point.
		inline void expandBy(const Point p) {
			radius = std::max(radius, (p - center).length());
		}

		/// Check whether the specified point is inside or on the sphere
		inline bool contains(const Point p) const {
			return (p - center).length() <= radius;
		}

		/// Equality test
		inline bool operator==(const BSphere &boundingSphere) const {
			return center == boundingSphere.center && radius == boundingSphere.radius;
		}

		/// Inequality test
		inline bool operator!=(const BSphere &boundingSphere) const {
			return center != boundingSphere.center || radius != boundingSphere.radius;
		}

		/**
		* \brief Calculate the intersection points with the given ray
		* \return \c true if the ray intersects the bounding sphere
		*
		* \remark In the Python bindings, this function returns the
		* \c nearT and \c farT values as a tuple (or \c None, when no
		* intersection was found)
		*/
		inline bool rayIntersect(const Ray &ray, Float &nearHit, Float &farHit) const {
			Vector o = ray.o - center;
			Float A = ray.d.lengthSquared();
			Float B = 2 * dot(o, ray.d);
			Float C = o.lengthSquared() - radius*radius;

			return solveQuadratic(A, B, C, nearHit, farHit);
		}

		/// Return a string representation of the bounding sphere
		inline std::string toString() const {
			std::ostringstream oss;
			oss << "BSphere[center = " << center.toString()
				<< ", radius = " << radius << "]";
			return oss.str();
		}
	};




}



#endif



