#ifndef __Warp_h__
#define __Warp_h__

#include "Vector.h"
#include "Point.h"

namespace Dinodon {


namespace warp {

	/// Convert an uniformly distributed square sample into barycentric coordinates
	extern Point2 squareToUniformTriangle(const Point2 &sample);

}




}



#endif





