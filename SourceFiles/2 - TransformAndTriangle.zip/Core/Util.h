#ifndef __Util_h__
#define __Util_h__

#include "Fwd.h"


namespace Dinodon {


	// -----------------------------------------------------------------------
	//! @{ \name Numerical utility functions
	// -----------------------------------------------------------------------

	/**
	* \brief Solve a quadratic equation of the form a*x^2 + b*x + c = 0.
	* \return \c true if a solution could be found
	*/
	extern bool solveQuadratic(Float a, Float b,
		Float c, Float &x0, Float &x1);



}








#endif




