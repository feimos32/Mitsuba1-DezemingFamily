#include "Warp.h"
#include "Math.h"

namespace Dinodon {

namespace warp {

	Point2 squareToUniformTriangle(const Point2 &sample) {
		Float a = math::safe_sqrt(1.0f - sample.x);
		return Point2(1 - a, a * sample.y);
	}



}


}






