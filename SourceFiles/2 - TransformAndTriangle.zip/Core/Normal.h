#pragma once
#ifndef __Normal_h__
#define __Normal_h__


#include "Vector.h"

namespace Dinodon {

	struct Normal : public TVector3<Float> {

		Normal() { }

		/// Initialize the vector with the specified X and Z components
		Normal(Float x, Float y, Float z) : TVector3<Float>(x, y, z) { }

		/// Initialize all components of the the normal with the specified value
		explicit Normal(Float val) : TVector3<Float>(val) { }

		/// Construct a normal from a vector data structure
		Normal(const TVector3<Float> &v) : TVector3<Float>(v.x, v.y, v.z) { }

		/// Assign a vector to this normal
		void operator=(const TVector3<Float> &v) {
			x = v.x; y = v.y; z = v.z;
		}
	};

	inline Normal normalize(const Normal &n) {
		return n / n.length();
	}

}

#define  TextDinNormal(text, norm)  DebugText::getDebugText()->addContents(QString(text) + " -Normal- " + norm.toString().c_str())

#endif




