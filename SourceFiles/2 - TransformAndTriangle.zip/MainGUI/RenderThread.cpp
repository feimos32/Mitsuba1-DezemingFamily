#include "RenderThread.h"
#include "DebugText.hpp"
#include <QTime>

#include "Shape/Triangle.h"
#include "Core/Ray.h"

RenderThread::RenderThread() {
	paintFlag = false;
	renderFlag = false;
}

RenderThread::~RenderThread() {
	
}

void RenderThread::run() {
	emit PrintString("Prepared to Render");

	// ��������������
	Dinodon::Point triP[6] = { Dinodon::Point(-1.0,1.0,-2.0), Dinodon::Point(-1.0,-1.0,-2.0), Dinodon::Point(1.0,-1.0,-2.0),
		Dinodon::Point(-1.0,1.0,-2.0), Dinodon::Point(1.0,-1.0,-2.0), Dinodon::Point(1.0,1.0,-2.0) };
	Dinodon::Triangle tri[2];
	tri[0].idx[0] = 0; tri[0].idx[1] = 1; tri[0].idx[2] = 2;
	tri[1].idx[0] = 3; tri[1].idx[1] = 4; tri[1].idx[2] = 5;

	// ��ʼִ����Ⱦ
	while (renderFlag) {
		QTime t;
		t.start();
		
		emit PrintString("Rendering");

		for (int i = 0; i < 800; i++) {
			for(int j = 0; j < 600; j++) {

				Dinodon::Point o(0.f, 0.f, 2.0f); 
				Dinodon::Vector v = Dinodon::normalize(Dinodon::Point((i - 400) * 0.005, (j - 300) * 0.005, 1.0f) - o);
				Dinodon::Ray r(o, v, 0);
				bool issect = false;
				for (int k = 0; k < 2; k++) {
					Dinodon::Float u, v, t;
					if (tri[k].rayIntersect(triP, r, u, v, t)) issect = true;
				}
				if(issect) p_framebuffer->set_uc(i, j, 0, 255);
				else p_framebuffer->set_uc(i, j, 0, 0);
				p_framebuffer->set_uc(i, j, 1, 0);
				p_framebuffer->set_uc(i, j, 2, 0);
				p_framebuffer->set_uc(i, j, 3, 255);
			}
		}

		
		emit PaintBuffer(p_framebuffer->getUCbuffer(), 800, 600, 4);
			
		while (t.elapsed() < 20);
	}
	
}











