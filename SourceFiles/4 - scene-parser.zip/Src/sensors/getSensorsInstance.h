#ifndef __getSensorsInstance_h__
#define __getSensorsInstance_h__


MTS_NAMESPACE_BEGIN




MTS_NAMESPACE_END

#endif






