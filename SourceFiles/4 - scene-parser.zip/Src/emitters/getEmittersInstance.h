#ifndef __getEmitttersInstance_h__
#define __getEmitttersInstance_h__


MTS_NAMESPACE_BEGIN




MTS_NAMESPACE_END

#endif






