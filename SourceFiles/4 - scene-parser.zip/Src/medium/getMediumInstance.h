#ifndef __getMediumInstance_h__
#define __getMediumInstance_h__


MTS_NAMESPACE_BEGIN




MTS_NAMESPACE_END

#endif






