#include "InteractionDockWidget.h"

InteractionDockWidget::InteractionDockWidget(QWidget * parent) {
	setWindowTitle("Interaction");
	
	setFeatures(QDockWidget::DockWidgetMovable);
	setFeatures(QDockWidget::AllDockWidgetFeatures);
	
	dockCentralWidget = new QFrame;

	setWidget(dockCentralWidget);
	centerLayout = new QVBoxLayout;
	dockCentralWidget->setWindowFlags(Qt::FramelessWindowHint);
	dockCentralWidget->setLayout(centerLayout);
	

	setupDock();



	setMinimumWidth(200);
}

InteractionDockWidget::~InteractionDockWidget() {

}

void InteractionDockWidget::closeEvent(QCloseEvent * event) {

}

void InteractionDockWidget::setupDock() {

	renderButton = new QPushButton;
	renderButton->setText("Start Rendering");
	centerLayout->addWidget(renderButton);

	openIconsDirButton = new QPushButton;
	openIconsDirButton->setText("Open Icons Dir");
	centerLayout->addWidget(openIconsDirButton);
	connect(openIconsDirButton, SIGNAL(clicked()), this, SLOT(OpenImageDir()));
}










