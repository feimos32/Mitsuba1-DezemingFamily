#pragma once
#ifndef __IMAGraphicsView_h__
#define __IMAGraphicsView_h__

#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGraphicsScene>
#include <QPixmap>
#include <QMouseEvent>

#include <mitsuba/mitsuba.h>
#include <mitsuba/core/version.h>
#include <mitsuba/core/ref.h>
#include <mitsuba/core/matrix.h>
#include <mitsuba/core/bitmap.h>
#include <mitsuba/core/stream.h>
#include <mitsuba/core/mstream.h>
#include <mitsuba/core/fstream.h>
#include <mitsuba/core/appender.h>
#include <mitsuba/core/sched.h>
#include <mitsuba/core/object.h>
#include <mitsuba/core/plugin.h>
#include <mitsuba/core/shvector.h>
#include <mitsuba/core/statistics.h>
#include <mitsuba/core/fresolver.h>
#include <mitsuba/core/util.h>

#include <mitsuba/render/film.h>
#include <mitsuba/render/imageblock.h>
#include <mitsuba/render/scenehandler.h>

#include <boost/filesystem.hpp>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem/file_status.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/scoped_array.hpp>
#include <map>

struct SceneContext;

class IMAGraphicsView : public QGraphicsView {
	Q_OBJECT

public:
	IMAGraphicsView(QGraphicsView * parent = Q_NULLPTR);
	~IMAGraphicsView();
public:
	void getMap(QString mapname);
	SceneContext *loadScene(const QString &qFileName, const QString &destFile);
	std::map<std::string, std::string, mitsuba::SimpleStringOrdering> m_parameters;
private:
	int bottom, left, top, right, width, height;
	float _scale = 1.0f;
private:
	QGraphicsScene scene;
	QPixmap map;

signals:
	

private slots:
	void PaintBuffer(unsigned char * buffer, int width, int height, int channals);

protected:
	void mouseMoveEvent(QMouseEvent *event);
	void wheelEvent(QWheelEvent *event);
	void mousePressEvent(QMouseEvent *event);
	void drawBackground(QPainter *painter, const QRectF &rect);
	void mouseReleaseEvent(QMouseEvent *event);
};





#endif






