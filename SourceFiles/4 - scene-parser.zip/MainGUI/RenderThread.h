#ifndef __RenderThread_h__
#define __RenderThread_h__

#include <QThread>
#include <QString>

#include <mitsuba/mitsuba.h>

#include "IMAGraphicsView.h"

class RenderThread :public QThread {

	Q_OBJECT
public:
	RenderThread();
	~RenderThread();

public:
	bool renderFlag;
	bool paintFlag;

signals:
	void PrintString(char* s);
	void PaintBuffer(unsigned char* buffer, int width, int height, int channals);
private slots:
	


public:
	void run();

public:
	mitsuba::ref<mitsuba::Film> m_film;
	mitsuba::ref<mitsuba::Bitmap> m_bitmap;
};








#endif






